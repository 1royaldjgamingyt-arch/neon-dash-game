/**
 * NEON DASH — Professional 3D Endless Runner
 * Optimized for Android Mobile Browsers, Desktop HTML5 & Playgama
 * Pure HTML5 Canvas 2D Pseudo-3D Engine & Web Audio Synthesizer
 */

import {
  LANES,
  OBSTACLE_TYPES,
  POWERUP_TYPES,
  CONFIG,
  getLaneX,
  calculateSpeed,
  calculateScore,
  isPatternSolvable,
  checkCollision,
  checkCoinPickup,
  checkPowerupPickup,
  attractCoinTowardPlayer,
  DIFFICULTY_TIERS,
  getDifficultyTier,
  MISSIONS,
  evaluateMission,
  MILESTONES,
  checkNewMilestones,
  SKINS,
  checkNearMiss,
  ZONES,
  getComboMultiplier,
  calculateCoinReward
} from './rules.js';

// ============================================================================
// AUDIO SYNTHESIZER (Web Audio API - Zero External Files)
// ============================================================================
class SoundFX {
  constructor() {
    this.ctx = null;
    this.masterGain = null;
    this.sfxGain = null;
    this.musicGain = null;
    this.isMuted = false;
    this.sfxEnabled = true;
    this.musicEnabled = true;
    this.musicTimer = null;
    this.musicStep = 0;
    this.melodyStep = 0;
    // Upbeat energetic synthwave progression: A minor -> F major -> C major -> G major
    this.bassNotes = [
      110, 110, 164.8, 110, 87.3, 87.3, 130.8, 87.3,
      130.8, 130.8, 196, 130.8, 98, 98, 146.8, 98
    ];
    this.leadNotes = [
      440, 523.25, 659.25, 523.25, 349.23, 440, 523.25, 440,
      523.25, 659.25, 783.99, 659.25, 392, 493.88, 587.33, 493.88
    ];
  }

  init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      this.ctx = new AudioCtx();

      this.masterGain = this.ctx.createGain();
      this.sfxGain = this.ctx.createGain();
      this.musicGain = this.ctx.createGain();

      this.masterGain.gain.value = this.isMuted ? 0 : 0.75;
      this.sfxGain.gain.value = this.sfxEnabled ? 0.85 : 0;
      this.musicGain.gain.value = this.musicEnabled ? 0.22 : 0;

      this.sfxGain.connect(this.masterGain);
      this.musicGain.connect(this.masterGain);
      this.masterGain.connect(this.ctx.destination);
    } catch (e) {
      console.warn('Web Audio not available:', e);
    }
  }

  ensureContext() {
    this.init();
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  setMuted(muted) {
    this.isMuted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(muted ? 0 : 0.75, this.ctx.currentTime);
    }
  }

  setSfxEnabled(enabled) {
    this.sfxEnabled = enabled;
    if (this.sfxGain && this.ctx) {
      this.sfxGain.gain.setValueAtTime(enabled ? 0.85 : 0, this.ctx.currentTime);
    }
  }

  setMusicEnabled(enabled) {
    this.musicEnabled = enabled;
    if (this.musicGain && this.ctx) {
      this.musicGain.gain.setValueAtTime(enabled ? 0.22 : 0, this.ctx.currentTime);
    }
    if (enabled) {
      this.startMusic();
    } else {
      this.stopMusic();
    }
  }

  playJump() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(180, t);
      osc.frequency.exponentialRampToValueAtTime(620, t + 0.16);

      gain.gain.setValueAtTime(0.35, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.18);
    } catch (e) {}
  }

  playSlide() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(360, t);
      osc.frequency.exponentialRampToValueAtTime(70, t + 0.22);

      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);

      osc.connect(gain);
      gain.connect(this.sfxGain);

      osc.start(t);
      osc.stop(t + 0.22);
    } catch (e) {}
  }

  playCoin() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [987.77, 1318.51]; // B5, E6 crystal bell chime
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.045);
        gain.gain.setValueAtTime(0.28, t + idx * 0.045);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.045 + 0.24);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t + idx * 0.045);
        osc.stop(t + idx * 0.045 + 0.24);
      });
    } catch (e) {}
  }

  playComboChime(multiplier = 2) {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const baseFreq = multiplier >= 10 ? 1046.5 : (multiplier >= 5 ? 880 : (multiplier >= 3 ? 659.25 : 523.25));
      const chords = [baseFreq, baseFreq * 1.25, baseFreq * 1.5];
      chords.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t + idx * 0.04);
        gain.gain.setValueAtTime(0.24, t + idx * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.04 + 0.22);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t + idx * 0.04);
        osc.stop(t + idx * 0.04 + 0.22);
      });
    } catch (e) {}
  }

  playPowerup() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const chords = [523.25, 659.25, 783.99, 1046.5]; // C major fanfare
      chords.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.05);
        gain.gain.setValueAtTime(0.3, t + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.3);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t + idx * 0.05);
        osc.stop(t + idx * 0.05 + 0.3);
      });
    } catch (e) {}
  }

  playShieldBreak() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.exponentialRampToValueAtTime(110, t + 0.25);
      gain.gain.setValueAtTime(0.5, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.25);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.25);
    } catch (e) {}
  }

  playLaneSwitch() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(320, t);
      osc.frequency.exponentialRampToValueAtTime(480, t + 0.07);
      gain.gain.setValueAtTime(0.18, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.07);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.07);
    } catch (e) {}
  }

  playCrash() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(140, t);
      osc.frequency.exponentialRampToValueAtTime(35, t + 0.45);
      gain.gain.setValueAtTime(0.65, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.45);
    } catch (e) {}
  }

  playMissionComplete() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [587.33, 739.99, 880, 1174.66];
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, t + idx * 0.06);
        gain.gain.setValueAtTime(0.25, t + idx * 0.06);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.06 + 0.28);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t + idx * 0.06);
        osc.stop(t + idx * 0.06 + 0.28);
      });
    } catch (e) {}
  }

  playMilestone() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const notes = [523.25, 659.25, 783.99, 1046.5, 1318.5];
      notes.forEach((freq, idx) => {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, t + idx * 0.05);
        gain.gain.setValueAtTime(0.3, t + idx * 0.05);
        gain.gain.exponentialRampToValueAtTime(0.001, t + idx * 0.05 + 0.35);
        osc.connect(gain);
        gain.connect(this.sfxGain);
        osc.start(t + idx * 0.05);
        osc.stop(t + idx * 0.05 + 0.35);
      });
    } catch (e) {}
  }

  playRevive() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sawtooth';
      osc.frequency.setValueAtTime(220, t);
      osc.frequency.exponentialRampToValueAtTime(880, t + 0.4);
      gain.gain.setValueAtTime(0.4, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.45);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.45);
    } catch (e) {}
  }

  playLanding() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(95, t);
      osc.frequency.exponentialRampToValueAtTime(38, t + 0.12);
      gain.gain.setValueAtTime(0.24, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.12);
    } catch (e) {}
  }

  playNearMiss() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(980, t);
      osc.frequency.exponentialRampToValueAtTime(1760, t + 0.14);
      gain.gain.setValueAtTime(0.32, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.14);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.14);
    } catch (e) {}
  }

  playClick() {
    this.ensureContext();
    if (!this.ctx || this.isMuted || !this.sfxEnabled) return;
    try {
      const t = this.ctx.currentTime;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(600, t);
      osc.frequency.exponentialRampToValueAtTime(300, t + 0.04);
      gain.gain.setValueAtTime(0.12, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
      osc.connect(gain);
      gain.connect(this.sfxGain);
      osc.start(t);
      osc.stop(t + 0.04);
    } catch (e) {}
  }

  startMusic() {
    this.ensureContext();
    if (this.musicTimer || !this.ctx || !this.musicEnabled || this.isMuted) return;

    this.musicTimer = setInterval(() => {
      if (!this.ctx || this.ctx.state === 'suspended' || !this.musicEnabled || this.isMuted) return;
      try {
        const t = this.ctx.currentTime;
        const note = this.bassNotes[this.musicStep % this.bassNotes.length];
        this.musicStep++;

        // Bass oscillator
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(note, t);

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'lowpass';
        filter.frequency.setValueAtTime(380, t);
        filter.frequency.exponentialRampToValueAtTime(180, t + 0.16);

        gain.gain.setValueAtTime(0.18, t);
        gain.gain.exponentialRampToValueAtTime(0.001, t + 0.17);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.musicGain);

        osc.start(t);
        osc.stop(t + 0.17);

        // Hi-hat pulse every other beat
        if (this.musicStep % 2 === 0) {
          const hatOsc = this.ctx.createOscillator();
          const hatGain = this.ctx.createGain();
          const hatFilter = this.ctx.createBiquadFilter();
          hatOsc.type = 'square';
          hatFilter.type = 'highpass';
          hatFilter.frequency.setValueAtTime(6500, t);
          hatOsc.frequency.setValueAtTime(8000, t);
          hatGain.gain.setValueAtTime(0.035, t);
          hatGain.gain.exponentialRampToValueAtTime(0.001, t + 0.04);
          hatOsc.connect(hatFilter);
          hatFilter.connect(hatGain);
          hatGain.connect(this.musicGain);
          hatOsc.start(t);
          hatOsc.stop(t + 0.04);
        }
      } catch (e) {}
    }, 145);
  }

  stopMusic() {
    if (this.musicTimer) {
      clearInterval(this.musicTimer);
      this.musicTimer = null;
    }
  }
}

// ============================================================================
// PARTICLE SYSTEM (Sparks, Coin Glows, Exhaust Trails, Debris)
// ============================================================================
class ParticleSystem {
  constructor(maxParticles = 180) {
    this.pool = [];
    this.maxParticles = maxParticles;
    for (let i = 0; i < maxParticles; i++) {
      this.pool.push({
        active: false,
        x: 0,
        y: 0,
        vx: 0,
        vy: 0,
        life: 0,
        maxLife: 1,
        size: 3,
        color: '#00f3ff',
        gravity: 0,
        decay: 1
      });
    }
  }

  spawn(x, y, vx, vy, life, size, color, gravity = 0) {
    const p = this.pool.find(item => !item.active);
    if (!p) return;
    p.active = true;
    p.x = x;
    p.y = y;
    p.vx = vx;
    p.vy = vy;
    p.life = life;
    p.maxLife = life;
    p.size = size;
    p.color = color;
    p.gravity = gravity;
  }

  burst(x, y, count = 12, color = '#00f3ff', speed = 140) {
    for (let i = 0; i < count; i++) {
      const angle = (Math.PI * 2 * i) / count + (Math.random() - 0.5) * 0.4;
      const spd = speed * (0.6 + Math.random() * 0.8);
      this.spawn(
        x,
        y,
        Math.cos(angle) * spd,
        Math.sin(angle) * spd - 40,
        0.35 + Math.random() * 0.35,
        2.5 + Math.random() * 3.5,
        color,
        280
      );
    }
  }

  sparks(x, y, count = 8, color = '#ffb800') {
    for (let i = 0; i < count; i++) {
      const vx = (Math.random() - 0.5) * 160;
      const vy = -Math.random() * 120 - 20;
      this.spawn(x, y, vx, vy, 0.2 + Math.random() * 0.25, 2.0, color, 400);
    }
  }

  update(dt) {
    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.active) continue;
      p.life -= dt;
      if (p.life <= 0) {
        p.active = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.vy += p.gravity * dt;
    }
  }

  render(ctx) {
    for (let i = 0; i < this.pool.length; i++) {
      const p = this.pool[i];
      if (!p.active) continue;
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.fillStyle = p.color;
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.size * alpha, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }
}

// ============================================================================
// MAIN GAME CONTROLLER & PSEUDO-3D RAILWAY RUNNER ENGINE
// ============================================================================
export class NeonDashGame {
  constructor() {
    this.canvas = document.getElementById('game-canvas');
    this.ctx = this.canvas.getContext('2d', { alpha: false });

    // Virtual Internal Resolution (optimally balanced for mobile & desktop)
    this.V_WIDTH = 480;
    this.V_HEIGHT = 854;
    this.scaleX = 1;
    this.scaleY = 1;

    // Pseudo-3D Perspective Camera Projection
    this.horizonY = this.V_HEIGHT * 0.34;
    this.roadBottomY = this.V_HEIGHT * 0.91;
    this.roadBottomWidth = 430;
    this.roadTopWidth = 72;
    this.cameraDepth = 300;

    // Persistent Storage & State
    this.storage = this.initStorage();
    this.state = 'title'; // 'title' | 'playing' | 'paused' | 'gameover'
    this.isBridgeInitialized = false;
    this.audio = new SoundFX();
    this.particles = new ParticleSystem(180);

    // Dynamic Gameplay Variables
    this.distance = 0;
    this.coins = 0;
    this.runCoins = 0;
    this.speed = CONFIG.BASE_SPEED;
    this.score = 0;
    this.roadGridOffset = 0;
    this.hitstopTimer = 0;
    this.shakeDuration = 0;
    this.shakeIntensity = 0;
    this.invulnerableTimer = 0;
    this.runTime = 0;
    this.currentTier = 1;
    this.currentZone = ZONES.METRO;
    this.zoneTransition = 0;
    this.cameraYOffset = 0;
    this.landingSquash = 0;
    this.inputBuffer = [];
    this.dodgedObstacles = 0;
    this.hasRevivedThisRun = false;
    this.reviveCountdown = 5;
    this.reviveInterval = null;
    this.completedMissionsThisRun = new Set();
    this.toastTimer = null;

    // Active Power-ups State
    this.activePowerups = {
      magnet: 0, // timer in seconds
      shield: false, // 1 hit protection
      boost: 0,  // timer in seconds
      double: 0  // timer in seconds (2x coins)
    };

    // Combo Streak Multiplier State
    this.comboCount = 0;
    this.comboMultiplier = 1;
    this.comboTimer = 0;
    this.comboMaxTimer = 2.4;
    this.highestCombo = 1;
    this.floatingCombos = [];

    // Player Entity (Detailed Cartoon 3D Streetwear Runner)
    this.player = {
      lane: LANES.CENTER,
      targetLane: LANES.CENTER,
      x: this.V_WIDTH * 0.5,
      z: 0,
      jumpY: 0,
      vy: 0,
      isJumping: false,
      isSliding: false,
      slideTimer: 0,
      tilt: 0,
      runCycle: 0,
      collisionAnim: 0
    };

    // Environment & Scenery
    this.obstacles = [];
    this.coinsList = [];
    this.powerupsList = [];
    this.overheadBridges = [];
    this.clouds = this.generateClouds();
    this.stars = this.generateStars();
    this.cityBuildings = this.generateCitySkyline();
    this.flyingCars = this.generateFlyingCars();
    this.nextSpawnZ = 1350; // Opening runway distance

    // Touch & Swipe Tracking
    this.touchStartX = 0;
    this.touchStartY = 0;
    this.touchStartTime = 0;
    this.isSwiping = false;

    // Cache DOM Elements for zero garbage collection during gameplay
    this.hudScore = document.getElementById('hud-score');
    this.hudCoins = document.getElementById('hud-coins');
    this.hudDistance = document.getElementById('hud-distance');
    this.hudBestChip = document.getElementById('hud-best-chip');
    this.hudSpeedVal = document.getElementById('hud-speed-val');
    this.hudMissionChip = document.getElementById('hud-mission-chip');
    this.hudMissionTitle = document.getElementById('hud-mission-title');
    this.hudMissionFill = document.getElementById('hud-mission-fill');
    this.hudMissionIcon = document.getElementById('hud-mission-icon');
    this.hudZoneBadge = document.getElementById('hud-zone-badge');
    this.hudZoneName = document.getElementById('hud-zone-name');

    // Combo Streak HUD Elements
    this.hudComboChip = document.getElementById('hud-combo-chip');
    this.hudComboMult = document.getElementById('hud-combo-mult');
    this.hudComboFill = document.getElementById('hud-combo-fill');

    // Power-up HUD Elements
    this.puMagnet = document.getElementById('powerup-magnet');
    this.puShield = document.getElementById('powerup-shield');
    this.puBoost = document.getElementById('powerup-boost');
    this.puDouble = document.getElementById('powerup-double');
    this.meterMagnet = document.getElementById('meter-magnet');
    this.meterShield = document.getElementById('meter-shield');
    this.meterBoost = document.getElementById('meter-boost');
    this.meterDouble = document.getElementById('meter-double');
    this.timeMagnet = document.getElementById('time-magnet');
    this.timeBoost = document.getElementById('time-boost');
    this.timeDouble = document.getElementById('time-double');

    // Toasts
    this.toastBanner = document.getElementById('toast-banner');
    this.toastIcon = document.getElementById('toast-icon');
    this.toastTitle = document.getElementById('toast-title');
    this.toastDesc = document.getElementById('toast-desc');

    // Modals & Panels
    this.titleBestScore = document.getElementById('title-best-score');
    this.titleTotalCoins = document.getElementById('title-total-coins');
    this.titleMissionsList = document.getElementById('title-missions-list');
    this.milestoneLabel = document.getElementById('milestone-label');
    this.milestoneFill = document.getElementById('milestone-fill');

    this.goScore = document.getElementById('go-score');
    this.goDistance = document.getElementById('go-distance');
    this.goCoins = document.getElementById('go-coins');
    this.goBest = document.getElementById('go-best');
    this.goCombo = document.getElementById('go-combo');
    this.goNewBest = document.getElementById('go-new-best');
    this.goMissionsList = document.getElementById('go-missions-list');

    // Revive Modal
    this.reviveModal = document.getElementById('revive-modal');
    this.reviveCountdownText = document.getElementById('revive-countdown-text');
    this.reviveProgressRing = document.getElementById('revive-progress-ring');
    this.btnReviveAd = document.getElementById('btn-revive-ad');
    this.btnReviveCoins = document.getElementById('btn-revive-coins');
    this.btnReviveSkip = document.getElementById('btn-revive-skip');

    // Tutorial & Skins Modals
    this.tutorialModal = document.getElementById('tutorial-modal');
    this.skinsModal = document.getElementById('skins-modal');
    this.skinsGridContainer = document.getElementById('skins-grid-container');
    this.skinsCoinsDisplay = document.getElementById('skins-coins-display');

    this.lastTime = 0;

    // Initialization
    this.setupEventListeners();
    this.setupTouchControls();
    this.setupSettingsToggles();
    this.initPlaygamaBridge();
    this.handleResize();

    window.game = this;

    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      this.startGame();
    } else {
      this.setState('title');
    }

    requestAnimationFrame((t) => this.loop(t));
  }

  // ==========================================================================
  // PLAYGAMA BRIDGE SDK ADAPTER (Safe fallback if SDK is absent)
  // ==========================================================================
  initPlaygamaBridge() {
    if (typeof window !== 'undefined' && window.bridge) {
      try {
        const b = window.bridge;
        b.initialize?.()
          ?.then(() => {
            this.isBridgeInitialized = true;
            console.log('Playgama Bridge SDK initialized successfully');
            b.platform?.sendMessage?.('game_ready');
            // Cloud storage support per official docs
            if (b.storage?.get) {
              b.storage.get(['neon_dash_best_score', 'neon_dash_total_coins'])
                .then((data) => {
                  if (Array.isArray(data)) {
                    if (data[0] !== null && data[0] !== undefined) {
                      const cloudBest = parseInt(data[0], 10) || 0;
                      if (cloudBest > this.storage.bestScore) this.storage.bestScore = cloudBest;
                    }
                    if (data[1] !== null && data[1] !== undefined) {
                      const cloudCoins = parseInt(data[1], 10) || 0;
                      if (cloudCoins > this.storage.totalCoins) this.storage.totalCoins = cloudCoins;
                    }
                  } else if (data && typeof data === 'object') {
                    if (data.neon_dash_best_score != null) {
                      const cloudBest = parseInt(data.neon_dash_best_score, 10) || 0;
                      if (cloudBest > this.storage.bestScore) this.storage.bestScore = cloudBest;
                    }
                    if (data.neon_dash_total_coins != null) {
                      const cloudCoins = parseInt(data.neon_dash_total_coins, 10) || 0;
                      if (cloudCoins > this.storage.totalCoins) this.storage.totalCoins = cloudCoins;
                    }
                  }
                  if (this.state === 'title') {
                    this.titleBestScore.textContent = this.storage.bestScore.toLocaleString();
                    this.titleTotalCoins.textContent = this.storage.totalCoins.toLocaleString();
                  }
                })
                .catch((err) => {
                  console.warn('Playgama storage.get note:', err);
                });
            }

            // Official Playgama Bridge event: visibility_state_changed
            if (b.game?.on) {
              b.game.on('visibility_state_changed', (state) => {
                if (state === 'hidden') {
                  if (this.state === 'playing') this.setState('paused');
                  this.audio.setMusicEnabled(false);
                } else if (state === 'visible') {
                  if (this.storage.music && this.state === 'playing') {
                    this.audio.setMusicEnabled(true);
                  }
                }
              });
            }

            // Official Playgama Bridge event: interstitial_state_changed
            if (b.advertisement?.on) {
              b.advertisement.on('interstitial_state_changed', (state) => {
                if (state === 'opened') {
                  this.audio.setMuted(true);
                  if (this.state === 'playing') this.setState('paused');
                } else if (state === 'closed' || state === 'failed') {
                  if (!this.storage.muted) this.audio.setMuted(false);
                }
              });
            }
          })
          ?.catch((err) => {
            console.warn('Playgama Bridge initialization info:', err);
          });
      } catch (e) {
        console.warn('Playgama Bridge init skipped:', e);
      }
    }
  }

  // ==========================================================================
  // STORAGE & PREFERENCES
  // ==========================================================================
  initStorage() {
    const defaultData = {
      bestScore: 0,
      totalCoins: 0,
      muted: false,
      sfx: true,
      music: true,
      touchButtons: true,
      skin: 'classic',
      unlockedSkins: ['classic'],
      completedMilestones: [],
      tutorialSeen: false
    };

    try {
      const best = localStorage.getItem('neon_dash_best_score');
      const coins = localStorage.getItem('neon_dash_total_coins');
      const muted = localStorage.getItem('neon_dash_muted');
      const sfx = localStorage.getItem('neon_dash_sfx');
      const music = localStorage.getItem('neon_dash_music');
      const touchBtns = localStorage.getItem('neon_dash_touch_buttons');
      const skin = localStorage.getItem('neon_dash_skin');
      const unlocked = localStorage.getItem('neon_dash_unlocked_skins');
      const milestones = localStorage.getItem('neon_dash_completed_milestones');
      const tutorial = localStorage.getItem('neon_dash_tutorial_seen');

      if (best !== null) defaultData.bestScore = parseInt(best, 10) || 0;
      if (coins !== null) defaultData.totalCoins = parseInt(coins, 10) || 0;
      if (muted !== null) defaultData.muted = muted === 'true';
      if (sfx !== null) defaultData.sfx = sfx === 'true';
      if (music !== null) defaultData.music = music === 'true';
      if (touchBtns !== null) defaultData.touchButtons = touchBtns === 'true';
      if (skin && SKINS[skin]) defaultData.skin = skin;
      if (unlocked) {
        try {
          const parsed = JSON.parse(unlocked);
          if (Array.isArray(parsed)) defaultData.unlockedSkins = parsed;
        } catch (e) {}
      }
      if (milestones) {
        try {
          const parsed = JSON.parse(milestones);
          if (Array.isArray(parsed)) defaultData.completedMilestones = parsed;
        } catch (e) {}
      }
      if (tutorial !== null) defaultData.tutorialSeen = tutorial === 'true';
    } catch (e) {
      console.warn('LocalStorage unavailable, using in-memory state:', e);
    }
    return defaultData;
  }

  saveStorage() {
    try {
      localStorage.setItem('neon_dash_best_score', this.storage.bestScore.toString());
      localStorage.setItem('neon_dash_total_coins', this.storage.totalCoins.toString());
      localStorage.setItem('neon_dash_muted', this.storage.muted.toString());
      localStorage.setItem('neon_dash_sfx', this.storage.sfx.toString());
      localStorage.setItem('neon_dash_music', this.storage.music.toString());
      localStorage.setItem('neon_dash_touch_buttons', this.storage.touchButtons.toString());
      localStorage.setItem('neon_dash_skin', this.storage.skin);
      localStorage.setItem('neon_dash_unlocked_skins', JSON.stringify(this.storage.unlockedSkins));
      localStorage.setItem('neon_dash_completed_milestones', JSON.stringify(this.storage.completedMilestones));
      localStorage.setItem('neon_dash_tutorial_seen', this.storage.tutorialSeen.toString());
    } catch (e) {}

    // Cloud storage sync if running on Playgama Bridge
    if (this.isBridgeInitialized && typeof window !== 'undefined' && window.bridge?.storage?.set) {
      try {
        window.bridge.storage.set(
          ['neon_dash_best_score', 'neon_dash_total_coins', 'neon_dash_skin'],
          [this.storage.bestScore.toString(), this.storage.totalCoins.toString(), this.storage.skin]
        );
      } catch (e) {}
    }
  }

  // ==========================================================================
  // SCENERY PROCEDURAL GENERATION
  // ==========================================================================
  generateClouds() {
    const clouds = [];
    for (let i = 0; i < 6; i++) {
      clouds.push({
        x: Math.random() * this.V_WIDTH,
        y: 20 + Math.random() * (this.horizonY - 50),
        w: 60 + Math.random() * 80,
        h: 22 + Math.random() * 20,
        speed: 8 + Math.random() * 12,
        opacity: 0.15 + Math.random() * 0.2
      });
    }
    return clouds;
  }

  generateStars() {
    const stars = [];
    for (let i = 0; i < 48; i++) {
      stars.push({
        x: Math.random() * this.V_WIDTH,
        y: Math.random() * (this.horizonY - 8),
        size: 1 + Math.random() * 2,
        blinkSpeed: 1.2 + Math.random() * 2.8,
        blinkOffset: Math.random() * Math.PI * 2,
        color: Math.random() > 0.4 ? '#ffffff' : (Math.random() > 0.5 ? '#ffb800' : '#00f3ff')
      });
    }
    return stars;
  }

  generateFlyingCars() {
    return [
      { x: -60, y: 80, speed: 50, color: '#00f3ff', len: 32 },
      { x: this.V_WIDTH + 80, y: 130, speed: -60, color: '#ff007f', len: 36 },
      { x: -120, y: 175, speed: 65, color: '#ffb800', len: 28 }
    ];
  }

  generateCitySkyline() {
    const buildings = [];
    const count = 18;
    for (let i = 0; i < count; i++) {
      const w = 28 + Math.random() * 34;
      const h = 85 + Math.random() * 160;
      const x = (i / count) * this.V_WIDTH * 1.35 - this.V_WIDTH * 0.18;
      const hue = Math.random() > 0.5 ? '#00f3ff' : '#ff007f';
      const billboard = Math.random() > 0.65 ? (Math.random() > 0.5 ? 'METRO' : 'DASH') : null;
      buildings.push({
        x,
        w,
        h,
        windows: Math.floor(Math.random() * 7) + 3,
        hue,
        billboard
      });
    }
    return buildings;
  }

  // ==========================================================================
  // STATE MANAGEMENT
  // ==========================================================================
  // STATE MANAGEMENT
  // ==========================================================================
  setState(newState) {
    this.state = newState;
    document.body.dataset.state = newState;

    if (newState === 'title') {
      if (this.titleBestScore) this.titleBestScore.textContent = this.storage.bestScore.toLocaleString();
      if (this.titleTotalCoins) this.titleTotalCoins.textContent = this.storage.totalCoins.toLocaleString();
      this.renderTitleMissions();
      this.renderMilestoneProgress();
      this.audio.stopMusic();
    } else if (newState === 'playing') {
      this.audio.startMusic();
    } else if (newState === 'paused') {
      this.audio.stopMusic();
    } else if (newState === 'revive') {
      this.audio.stopMusic();
    } else if (newState === 'gameover') {
      this.audio.stopMusic();
      const isNewBest = this.score > this.storage.bestScore;
      if (isNewBest) {
        this.storage.bestScore = this.score;
        if (this.goNewBest) this.goNewBest.style.display = 'inline-block';
      } else {
        if (this.goNewBest) this.goNewBest.style.display = 'none';
      }

      this.storage.totalCoins += this.runCoins;
      this.saveStorage();

      if (this.goScore) this.goScore.textContent = this.score.toLocaleString();
      if (this.goDistance) this.goDistance.textContent = `${Math.floor(this.distance)}m`;
      if (this.goCoins) this.goCoins.textContent = `+${this.runCoins}`;
      if (this.goBest) this.goBest.textContent = this.storage.bestScore.toLocaleString();
      if (this.goCombo) this.goCombo.textContent = `x${this.highestCombo}`;
      this.renderGameOverMissions();

      // Notify Playgama Bridge if present
      if (this.isBridgeInitialized && typeof window !== 'undefined' && window.bridge) {
        try {
          window.bridge.game?.gameplayStop?.();
          window.bridge.advertisement?.showInterstitial?.();
          const lb = window.bridge.leaderboards || window.bridge.leaderboard;
          if (lb?.setScore) {
            lb.setScore({ score: this.storage.bestScore })?.catch?.(() => {});
          }
        } catch (e) {}
      }
    }
  }

  showToast(icon, title, desc, duration = 3000) {
    if (!this.toastBanner) return;
    if (this.toastTimer) clearTimeout(this.toastTimer);
    if (this.toastIcon) this.toastIcon.textContent = icon;
    if (this.toastTitle) this.toastTitle.textContent = title;
    if (this.toastDesc) this.toastDesc.textContent = desc;
    this.toastBanner.style.display = 'flex';
    this.toastTimer = setTimeout(() => {
      if (this.toastBanner) this.toastBanner.style.display = 'none';
      this.toastTimer = null;
    }, duration);
  }

  showReviveModal() {
    this.setState('revive');
    this.audio.stopMusic();
    if (this.reviveModal) {
      this.reviveModal.classList.add('active');
      this.reviveModal.style.display = 'flex';
      this.reviveModal.style.opacity = '1';
      this.reviveModal.style.pointerEvents = 'auto';
    }
    this.reviveCountdown = 5;
    if (this.reviveCountdownText) this.reviveCountdownText.textContent = '5';
    if (this.reviveProgressRing) this.reviveProgressRing.style.strokeDashoffset = '0';

    // Check Playgama ad availability
    const hasBridgeAds = typeof window !== 'undefined' && Boolean(window.bridge?.advertisement?.showRewardedVideo);
    if (this.btnReviveAd) {
      this.btnReviveAd.style.display = hasBridgeAds ? 'flex' : 'none';
    }

    if (this.btnReviveCoins) {
      if (this.storage.totalCoins >= 50) {
        this.btnReviveCoins.innerHTML = '<span class="btn-icon">🪙</span> REVIVE (50 COINS)';
      } else {
        this.btnReviveCoins.innerHTML = '<span class="btn-icon">⚡</span> FREE EMERGENCY REBOOT';
      }
    }

    if (this.reviveInterval) clearInterval(this.reviveInterval);
    const totalTime = 5;
    let elapsed = 0;

    this.reviveInterval = setInterval(() => {
      elapsed += 0.1;
      const remaining = Math.max(0, Math.ceil(totalTime - elapsed));
      if (this.reviveCountdownText) this.reviveCountdownText.textContent = remaining.toString();

      if (this.reviveProgressRing) {
        const offset = (elapsed / totalTime) * 264;
        this.reviveProgressRing.style.strokeDashoffset = offset.toString();
      }

      if (elapsed >= totalTime) {
        this.finishReviveTimeout();
      }
    }, 100);
  }

  finishReviveTimeout() {
    if (this.reviveInterval) {
      clearInterval(this.reviveInterval);
      this.reviveInterval = null;
    }
    if (this.reviveModal) {
      this.reviveModal.classList.remove('active');
      this.reviveModal.style.display = 'none';
      this.reviveModal.style.opacity = '0';
      this.reviveModal.style.pointerEvents = 'none';
    }
    this.setState('gameover');
  }

  performRevive() {
    if (this.reviveInterval) {
      clearInterval(this.reviveInterval);
      this.reviveInterval = null;
    }
    this.hasRevivedThisRun = true;
    if (this.reviveModal) {
      this.reviveModal.classList.remove('active');
      this.reviveModal.style.display = 'none';
      this.reviveModal.style.opacity = '0';
      this.reviveModal.style.pointerEvents = 'none';
    }

    // Clear nearby obstacles (safely within 480m ahead)
    this.obstacles = this.obstacles.filter(obs => obs.z > this.player.z + 480);
    this.nextSpawnZ = Math.max(this.nextSpawnZ, 850);

    // Center player safely with invulnerability shield
    this.player.lane = LANES.CENTER;
    this.player.targetLane = LANES.CENTER;
    this.player.x = this.V_WIDTH * 0.5;
    this.player.jumpY = 0;
    this.player.vy = 0;
    this.player.isJumping = false;
    this.player.isSliding = false;
    this.invulnerableTimer = 2.8;

    this.audio.playRevive();
    this.showToast('⚡', 'SYSTEM REBOOTED', 'Shield Active! Keep Dashing!');
    this.setState('playing');
  }

  openTutorial() {
    if (this.tutorialModal) {
      this.tutorialModal.classList.add('active');
      this.tutorialModal.style.display = 'flex';
      this.tutorialModal.style.opacity = '1';
      this.tutorialModal.style.pointerEvents = 'auto';
    }
  }

  closeTutorial() {
    if (this.tutorialModal) {
      this.tutorialModal.classList.remove('active');
      this.tutorialModal.style.display = 'none';
      this.tutorialModal.style.opacity = '0';
      this.tutorialModal.style.pointerEvents = 'none';
    }
    this.storage.tutorialSeen = true;
    this.saveStorage();
  }

  openSkinsShop() {
    if (this.skinsModal) {
      this.skinsModal.classList.add('active');
      this.skinsModal.style.display = 'flex';
      this.skinsModal.style.opacity = '1';
      this.skinsModal.style.pointerEvents = 'auto';
    }
    this.renderSkinsShop();
  }

  closeSkinsShop() {
    if (this.skinsModal) {
      this.skinsModal.classList.remove('active');
      this.skinsModal.style.display = 'none';
      this.skinsModal.style.opacity = '0';
      this.skinsModal.style.pointerEvents = 'none';
    }
  }

  renderSkinsShop() {
    if (!this.skinsGridContainer) return;
    if (this.skinsCoinsDisplay) this.skinsCoinsDisplay.textContent = this.storage.totalCoins.toLocaleString();
    this.skinsGridContainer.innerHTML = '';

    Object.values(SKINS).forEach(skin => {
      const isEquipped = this.storage.skin === skin.id;
      const isOwned = this.storage.unlockedSkins.includes(skin.id);

      const item = document.createElement('div');
      item.className = `skin-item ${isEquipped ? 'equipped' : ''}`;

      let btnHtml = '';
      if (isEquipped) {
        btnHtml = `<button class="skin-action-btn equipped" disabled>EQUIPPED</button>`;
      } else if (isOwned) {
        btnHtml = `<button class="skin-action-btn equip" data-skin="${skin.id}">EQUIP</button>`;
      } else {
        btnHtml = `<button class="skin-action-btn unlock" data-skin="${skin.id}" data-price="${skin.price}">UNLOCK (${skin.price}🪙)</button>`;
      }

      item.innerHTML = `
        <div class="skin-preview-swatch" style="background: ${skin.hoodie}; border-color: ${skin.accent};">
          <div style="width: 14px; height: 14px; border-radius: 4px; background: ${skin.backpack};"></div>
        </div>
        <div class="skin-details">
          <span class="skin-name">${skin.name}</span>
          <span class="skin-desc">${skin.desc}</span>
        </div>
        ${btnHtml}
      `;

      this.skinsGridContainer.appendChild(item);
    });

    // Wire clicks
    this.skinsGridContainer.querySelectorAll('.skin-action-btn.equip').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const skinId = e.currentTarget.getAttribute('data-skin');
        this.storage.skin = skinId;
        this.saveStorage();
        this.renderSkinsShop();
        this.showToast('👕', 'SUIT EQUIPPED', `${SKINS[skinId]?.name || 'Suit'} activated!`);
      });
    });

    this.skinsGridContainer.querySelectorAll('.skin-action-btn.unlock').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const skinId = e.currentTarget.getAttribute('data-skin');
        const price = parseInt(e.currentTarget.getAttribute('data-price'), 10) || 0;
        if (this.storage.totalCoins >= price) {
          this.storage.totalCoins -= price;
          if (!this.storage.unlockedSkins.includes(skinId)) {
            this.storage.unlockedSkins.push(skinId);
          }
          this.storage.skin = skinId;
          this.saveStorage();
          this.renderSkinsShop();
          if (this.titleTotalCoins) this.titleTotalCoins.textContent = this.storage.totalCoins.toLocaleString();
          this.audio.playMilestone();
          this.showToast('🎉', 'SUIT UNLOCKED!', `${SKINS[skinId]?.name || 'Suit'} is yours!`);
        } else {
          this.showToast('🪙', 'NOT ENOUGH COINS', `Need ${price - this.storage.totalCoins} more coins!`);
        }
      });
    });
  }

  renderTitleMissions() {
    if (!this.titleMissionsList) return;
    this.titleMissionsList.innerHTML = '';
    const stats = {
      coins: this.runCoins,
      time: this.runTime,
      dodged: this.dodgedObstacles
    };

    MISSIONS.forEach(mission => {
      const evalResult = evaluateMission(mission, stats);
      const isDone = this.completedMissionsThisRun.has(mission.id);

      const row = document.createElement('div');
      row.className = `mission-row ${isDone ? 'completed' : ''}`;
      row.innerHTML = `
        <span class="mission-icon">${mission.icon}</span>
        <div class="mission-details">
          <div class="mission-label-row">
            <span class="mission-title">${mission.title}</span>
            <span class="mission-progress-num">${isDone ? 'COMPLETED' : `${evalResult.progress}/${evalResult.target}`}</span>
          </div>
          <div class="mission-bar">
            <div class="mission-fill" style="width: ${isDone ? 100 : evalResult.percentage}%;"></div>
          </div>
        </div>
        <span class="mission-reward">+${mission.reward}🪙</span>
      `;
      this.titleMissionsList.appendChild(row);
    });
  }

  renderGameOverMissions() {
    if (!this.goMissionsList) return;
    this.goMissionsList.innerHTML = '';
    const stats = {
      coins: this.runCoins,
      time: this.runTime,
      dodged: this.dodgedObstacles
    };

    MISSIONS.forEach(mission => {
      const isDone = this.completedMissionsThisRun.has(mission.id);
      const evalResult = evaluateMission(mission, stats);

      const row = document.createElement('div');
      row.className = `mission-row ${isDone ? 'completed' : ''}`;
      row.innerHTML = `
        <span class="mission-icon">${mission.icon}</span>
        <div class="mission-details">
          <div class="mission-label-row">
            <span class="mission-title">${mission.title}</span>
            <span class="mission-progress-num">${isDone ? '+CLAIMED' : `${evalResult.progress}/${evalResult.target}`}</span>
          </div>
          <div class="mission-bar">
            <div class="mission-fill" style="width: ${isDone ? 100 : evalResult.percentage}%;"></div>
          </div>
        </div>
        <span class="mission-reward">+${mission.reward}🪙</span>
      `;
      this.goMissionsList.appendChild(row);
    });
  }

  renderMilestoneProgress() {
    if (!this.milestoneLabel || !this.milestoneFill) return;
    const best = this.storage.bestScore || 0;
    const nextMs = MILESTONES.find(ms => !this.storage.completedMilestones.includes(ms.id) && best < ms.score)
      || MILESTONES.find(ms => best < ms.score)
      || MILESTONES[MILESTONES.length - 1];

    if (best >= nextMs.score && this.storage.completedMilestones.includes(nextMs.id)) {
      this.milestoneLabel.textContent = `ALL MILESTONES MASTERED! 🏆`;
      this.milestoneFill.style.width = '100%';
    } else {
      const pct = Math.min(100, Math.round((best / nextMs.score) * 100));
      this.milestoneLabel.textContent = `${nextMs.score.toLocaleString()} PTS (+${nextMs.reward}🪙)`;
      this.milestoneFill.style.width = `${pct}%`;
    }
  }

  startGame() {
    this.closeTutorial();
    this.audio.ensureContext();
    this.storage.tutorialSeen = true;
    this.saveStorage();

    // Notify Playgama Bridge if present
    if (this.isBridgeInitialized && typeof window !== 'undefined' && window.bridge?.game?.gameplayStart) {
      try {
        window.bridge.game.gameplayStart();
      } catch (e) {}
    }

    this.distance = 0;
    this.coins = 0;
    this.runCoins = 0;
    this.speed = CONFIG.BASE_SPEED;
    this.score = 0;
    this.runTime = 0;
    this.currentTier = 1;
    this.dodgedObstacles = 0;
    this.hasRevivedThisRun = false;
    this.completedMissionsThisRun.clear();

    this.obstacles = [];
    this.coinsList = [];
    this.powerupsList = [];
    this.overheadBridges = [];
    this.nextSpawnZ = 1950; // Generous 4.5s opening runway
    this.hitstopTimer = 0;
    this.shakeDuration = 0;
    this.invulnerableTimer = 0;

    // Reset combo streak
    this.comboCount = 0;
    this.comboMultiplier = 1;
    this.comboTimer = 0;
    this.highestCombo = 1;
    this.floatingCombos = [];

    // Reset powerups
    this.activePowerups = {
      magnet: 0,
      shield: false,
      boost: 0,
      double: 0
    };

    // Introductory reward coins down the center track
    for (let c = 0; c < 8; c++) {
      this.coinsList.push({
        lane: LANES.CENTER,
        x: getLaneX(LANES.CENTER, this.V_WIDTH * 0.5, CONFIG.LANE_SPACING),
        z: 360 + c * 85,
        jumpY: 0,
        collected: false
      });
    }

    // Reset player position & physics
    this.player.lane = LANES.CENTER;
    this.player.targetLane = LANES.CENTER;
    this.player.x = this.V_WIDTH * 0.5;
    this.player.jumpY = 0;
    this.player.vy = 0;
    this.player.isJumping = false;
    this.player.isSliding = false;
    this.player.slideTimer = 0;
    this.player.tilt = 0;
    this.player.collisionAnim = 0;

    this.currentZone = ZONES.METRO;
    this.zoneTransition = 0;
    this.cameraYOffset = 0;
    this.landingSquash = 0;
    this.inputBuffer = [];

    if (this.hudZoneName) this.hudZoneName.textContent = 'METRO';
    const zoneKicker = document.querySelector('.hud-zone-kicker');
    if (zoneKicker) zoneKicker.textContent = 'ZONE 1';

    this.updateHUD();
    this.setState('playing');
  }

  // ==========================================================================
  // INPUT CONTROLS & BUFFER SYSTEM
  // ==========================================================================
  queueInput(action, value = 0) {
    if (this.state !== 'playing') return;
    this.inputBuffer.push({ action, value, time: performance.now() });
    if (this.inputBuffer.length > 4) this.inputBuffer.shift();
  }

  processInputBuffer() {
    if (this.inputBuffer.length === 0 || this.state !== 'playing') return;
    const now = performance.now();
    this.inputBuffer = this.inputBuffer.filter(cmd => (now - cmd.time) < 250);
    if (this.inputBuffer.length === 0) return;

    for (let i = 0; i < this.inputBuffer.length; i++) {
      const cmd = this.inputBuffer[i];
      let executed = false;

      if (cmd.action === 'moveLane') {
        const newLane = Math.max(-1, Math.min(1, this.player.targetLane + cmd.value));
        if (newLane !== this.player.targetLane) {
          this.player.targetLane = newLane;
          this.player.tilt = cmd.value * 0.32; // natural banking lean
          this.audio.playLaneSwitch();
          this.particles.sparks(this.player.x, this.roadBottomY - 10, 6, '#00f3ff');
          executed = true;
        }
      } else if (cmd.action === 'jump') {
        if (!this.player.isJumping) {
          this.player.isJumping = true;
          this.player.vy = 520; // upward jump impulse
          this.player.isSliding = false;
          this.audio.playJump();
          this.particles.burst(this.player.x, this.roadBottomY - 5, 8, '#00f3ff', 140);
          executed = true;
        }
      } else if (cmd.action === 'slide') {
        if (this.player.isJumping) {
          this.player.vy = -680; // fast downward dive
        }
        this.player.isSliding = true;
        this.player.slideTimer = 0.65; // slide duration
        this.audio.playSlide();
        this.particles.sparks(this.player.x, this.roadBottomY - 8, 10, '#ffb800');
        executed = true;
      }

      if (executed) {
        this.inputBuffer.splice(i, 1);
        break;
      }
    }
  }

  moveLane(direction) {
    if (this.state !== 'playing') return;
    this.queueInput('moveLane', direction);
    this.processInputBuffer();
  }

  jump() {
    if (this.state !== 'playing') return;
    this.queueInput('jump');
    this.processInputBuffer();
  }

  slide() {
    if (this.state !== 'playing') return;
    this.queueInput('slide');
    this.processInputBuffer();
  }

  togglePause() {
    if (this.state === 'playing') {
      this.setState('paused');
    } else if (this.state === 'paused') {
      this.setState('playing');
    }
  }

  setupEventListeners() {
    window.addEventListener('resize', () => this.handleResize());

    // Keyboard controls
    window.addEventListener('keydown', (e) => {
      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) {
        e.preventDefault();
      }

      if (this.state === 'title' || this.state === 'gameover') {
        if (e.code === 'Space' || e.code === 'Enter') {
          this.startGame();
          return;
        }
      }

      if (this.state === 'playing') {
        switch (e.code) {
          case 'ArrowLeft':
          case 'KeyA':
            this.moveLane(-1);
            break;
          case 'ArrowRight':
          case 'KeyD':
            this.moveLane(1);
            break;
          case 'ArrowUp':
          case 'KeyW':
          case 'Space':
            this.jump();
            break;
          case 'ArrowDown':
          case 'KeyS':
            this.slide();
            break;
          case 'KeyP':
          case 'Escape':
            this.togglePause();
            break;
          case 'KeyM':
            this.toggleMute();
            break;
        }
      } else if (this.state === 'paused') {
        if (e.code === 'KeyP' || e.code === 'Escape') {
          this.togglePause();
        }
      }
    });

    // Primary Buttons with reliable click and mobile touch handling
    const bindBtn = (id, callback) => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('click', (e) => {
        this.audio.playClick();
        callback(e);
      });
      el.addEventListener('touchend', (e) => {
        this.audio.playClick();
        callback(e);
      }, { passive: true });
    };

    bindBtn('btn-start', () => this.startGame());
    bindBtn('btn-restart', () => this.startGame());
    bindBtn('btn-pause-restart', () => this.startGame());
    bindBtn('btn-resume', () => this.setState('playing'));
    bindBtn('btn-menu', () => this.setState('title'));
    bindBtn('btn-pause-title', () => this.setState('title'));
    bindBtn('btn-pause', () => this.togglePause());
    bindBtn('btn-audio', () => this.toggleMute());
    bindBtn('btn-tutorial', () => this.openTutorial());
    bindBtn('btn-pause-tutorial', () => this.openTutorial());
    bindBtn('btn-close-tutorial', () => {
      this.closeTutorial();
      if (this.state === 'title') this.startGame();
    });
    bindBtn('btn-skins-shop', () => this.openSkinsShop());
    bindBtn('btn-pause-skins', () => this.openSkinsShop());
    bindBtn('btn-close-skins', () => this.closeSkinsShop());

    // Revive Buttons
    if (this.btnReviveCoins) {
      const handleCoinsRevive = () => {
        if (this.storage.totalCoins >= 50) {
          this.storage.totalCoins -= 50;
          this.saveStorage();
        }
        this.performRevive();
      };
      this.btnReviveCoins.addEventListener('click', handleCoinsRevive);
      this.btnReviveCoins.addEventListener('touchend', handleCoinsRevive, { passive: true });
    }

    if (this.btnReviveAd) {
      const handleAdRevive = () => {
        if (window.bridge?.advertisement?.showRewardedVideo) {
          window.bridge.advertisement.showRewardedVideo()
            .then((result) => {
              if (result?.rewarded || result === true) {
                this.performRevive();
              } else {
                this.finishReviveTimeout();
              }
            })
            .catch(() => {
              this.performRevive();
            });
        } else {
          this.performRevive();
        }
      };
      this.btnReviveAd.addEventListener('click', handleAdRevive);
      this.btnReviveAd.addEventListener('touchend', handleAdRevive, { passive: true });
    }

    if (this.btnReviveSkip) {
      this.btnReviveSkip.addEventListener('click', () => this.finishReviveTimeout());
      this.btnReviveSkip.addEventListener('touchend', () => this.finishReviveTimeout(), { passive: true });
    }

    // Unmute & unlock Web Audio on first user interaction anywhere
    const unlockAudio = () => {
      this.audio.ensureContext();
      window.removeEventListener('pointerdown', unlockAudio);
      window.removeEventListener('touchstart', unlockAudio);
      window.removeEventListener('keydown', unlockAudio);
    };
    window.addEventListener('pointerdown', unlockAudio, { passive: true });
    window.addEventListener('touchstart', unlockAudio, { passive: true });
    window.addEventListener('keydown', unlockAudio, { passive: true });

    // Handle tab visibility changes (Playgama / mobile app switching compliance)
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) {
        if (this.state === 'playing') {
          this.setState('paused');
        }
        this.audio.setMusicEnabled(false);
      } else {
        if (this.storage.music && this.state === 'playing') {
          this.audio.setMusicEnabled(true);
        }
      }
    });

    // Handle window blur (user clicks outside iframe or switches window)
    window.addEventListener('blur', () => {
      if (this.state === 'playing') {
        this.setState('paused');
      }
    });

    // Mobile orientation change listener
    window.addEventListener('orientationchange', () => {
      setTimeout(() => this.handleResize(), 120);
    });
  }

  setupTouchControls() {
    const container = document.getElementById('game-container') || this.canvas;
    if (!container) return;

    this.touchStartX = 0;
    this.touchStartY = 0;
    this.touchStartTime = 0;
    this.isSwiping = false;
    this.swipeHandled = false;

    const startGesture = (clientX, clientY) => {
      if (this.state !== 'playing') return;
      this.touchStartX = clientX;
      this.touchStartY = clientY;
      this.touchStartTime = performance.now();
      this.isSwiping = true;
      this.swipeHandled = false;
    };

    const processGesture = (currentX, currentY, isRelease = false) => {
      if (!this.isSwiping || this.state !== 'playing' || this.swipeHandled) return;

      const dx = currentX - this.touchStartX;
      const dy = currentY - this.touchStartY;
      const absX = Math.abs(dx);
      const absY = Math.abs(dy);
      const minDistance = isRelease ? 18 : 24;

      if (absX >= minDistance || absY >= minDistance) {
        this.swipeHandled = true;
        if (absX > absY) {
          // Horizontal swipe: lane switch
          if (dx > 0) {
            this.moveLane(1);
          } else {
            this.moveLane(-1);
          }
        } else {
          // Vertical swipe: jump or slide
          if (dy < 0) {
            this.jump();
          } else {
            this.slide();
          }
        }
      }
    };

    const endGesture = (clientX, clientY) => {
      if (!this.isSwiping) return;
      if (!this.swipeHandled && this.state === 'playing') {
        processGesture(clientX, clientY, true);
      }
      this.isSwiping = false;
      this.swipeHandled = false;
    };

    // Touch Event Listeners (Mobile iOS & Android)
    container.addEventListener(
      'touchstart',
      (e) => {
        if (e.touches.length === 1) {
          startGesture(e.touches[0].clientX, e.touches[0].clientY);
        }
      },
      { passive: false }
    );

    container.addEventListener(
      'touchmove',
      (e) => {
        if (this.isSwiping) {
          if (e.cancelable) e.preventDefault(); // Prevent page scroll / pull-to-refresh
          if (e.touches.length > 0) {
            processGesture(e.touches[0].clientX, e.touches[0].clientY, false);
          }
        }
      },
      { passive: false }
    );

    container.addEventListener(
      'touchend',
      (e) => {
        if (e.changedTouches.length > 0) {
          endGesture(e.changedTouches[0].clientX, e.changedTouches[0].clientY);
        } else {
          this.isSwiping = false;
        }
      },
      { passive: false }
    );

    container.addEventListener('touchcancel', () => {
      this.isSwiping = false;
      this.swipeHandled = false;
    });

    // Pointer Events (Mouse drag on desktop / trackpad)
    container.addEventListener('pointerdown', (e) => {
      if (e.pointerType === 'mouse' && e.button === 0) {
        startGesture(e.clientX, e.clientY);
      }
    });

    window.addEventListener('pointermove', (e) => {
      if (this.isSwiping && e.pointerType === 'mouse') {
        processGesture(e.clientX, e.clientY, false);
      }
    });

    window.addEventListener('pointerup', (e) => {
      if (this.isSwiping && e.pointerType === 'mouse') {
        endGesture(e.clientX, e.clientY);
      }
    });
  }

  toggleMute() {
    this.storage.muted = !this.storage.muted;
    this.audio.setMuted(this.storage.muted);
    this.updateAudioIcons();
    this.saveStorage();
  }

  updateAudioIcons() {
    const iconOn = document.getElementById('icon-sound-on');
    const iconOff = document.getElementById('icon-sound-off');
    if (this.storage.muted) {
      iconOn.style.display = 'none';
      iconOff.style.display = 'block';
    } else {
      iconOn.style.display = 'block';
      iconOff.style.display = 'none';
    }
  }

  setupSettingsToggles() {
    const toggleSfx = document.getElementById('toggle-sfx');
    if (toggleSfx) {
      toggleSfx.addEventListener('click', () => {
        this.storage.sfx = !this.storage.sfx;
        toggleSfx.classList.toggle('active', this.storage.sfx);
        this.audio.setSfxEnabled(this.storage.sfx);
        this.saveStorage();
      });
    }

    const toggleMusic = document.getElementById('toggle-music');
    if (toggleMusic) {
      toggleMusic.addEventListener('click', () => {
        this.storage.music = !this.storage.music;
        toggleMusic.classList.toggle('active', this.storage.music);
        this.audio.setMusicEnabled(this.storage.music);
        this.saveStorage();
      });
    }

    if (this.storage.muted) this.audio.setMuted(true);
    if (!this.storage.sfx && toggleSfx) {
      toggleSfx.classList.remove('active');
      this.audio.setSfxEnabled(false);
    }
    if (!this.storage.music && toggleMusic) {
      toggleMusic.classList.remove('active');
      this.audio.setMusicEnabled(false);
    }
    this.updateAudioIcons();
  }

  handleResize() {
    const container = document.getElementById('game-container');
    if (!container) return;
    const rect = container.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const w = Math.max(300, Math.round(rect.width || window.innerWidth));
    const h = Math.max(480, Math.round(rect.height || window.innerHeight));

    this.canvas.width = Math.round(w * dpr);
    this.canvas.height = Math.round(h * dpr);
    this.scaleX = this.canvas.width / this.V_WIDTH;
    this.scaleY = this.canvas.height / this.V_HEIGHT;
  }

  // ==========================================================================
  // SPAWNING MECHANICS (Railway Tracks, Trains, Barriers, Powerups, Coins)
  // ==========================================================================
  spawnWave() {
    const tier = getDifficultyTier(this.runTime);
    const laneKeys = [LANES.LEFT, LANES.CENTER, LANES.RIGHT];
    const availableTypes = [
      OBSTACLE_TYPES.BARRIER,   // Jump over
      OBSTACLE_TYPES.HURDLE,    // Jump over
      OBSTACLE_TYPES.OVERHEAD,  // Slide under
      OBSTACLE_TYPES.TRAIN,     // Dodge lane (subway car)
      OBSTACLE_TYPES.CRATE      // Dodge lane (rail cargo)
    ];

    // Number of obstacles dictated by difficulty tier
    let numObstacles = 1;
    if (tier.tier === 1) {
      numObstacles = 1; // Strict 1 obstacle for first 30s! Smooth, fair learning curve
    } else if (tier.tier === 2) {
      numObstacles = Math.random() > 0.45 ? 2 : 1;
    } else {
      numObstacles = Math.random() > 0.28 ? 2 : 1;
    }

    const shuffledLanes = [...laneKeys].sort(() => Math.random() - 0.5);
    const waveObstacles = [null, null, null];

    for (let i = 0; i < numObstacles; i++) {
      const lane = shuffledLanes[i];
      const type = availableTypes[Math.floor(Math.random() * availableTypes.length)];
      waveObstacles[lane + 1] = type;
    }

    // Ensure pattern is fair and solvable (never 3 impassable obstacles!)
    if (!isPatternSolvable(waveObstacles)) {
      const freeIdx = Math.floor(Math.random() * 3);
      waveObstacles[freeIdx] = Math.random() > 0.5 ? OBSTACLE_TYPES.BARRIER : null;
    }

    const spawnZ = 920;

    waveObstacles.forEach((type, laneIdx) => {
      const lane = laneIdx - 1;
      const laneX = getLaneX(lane, this.V_WIDTH * 0.5, CONFIG.LANE_SPACING);

      if (type) {
        this.obstacles.push({
          type,
          lane,
          x: laneX,
          z: spawnZ,
          height: (type === OBSTACLE_TYPES.BARRIER || type === OBSTACLE_TYPES.HURDLE) ? 42 : 80,
          cleared: false
        });

        // Risk-Reward: Spawn bonus coin arc on top of jumpable barriers!
        if ((type === OBSTACLE_TYPES.BARRIER || type === OBSTACLE_TYPES.HURDLE) && Math.random() > 0.2) {
          this.coinsList.push({
            lane,
            x: laneX,
            z: spawnZ,
            jumpY: 58,
            collected: false
          });
        }
      } else {
        // In open lane, occasionally spawn power-up or coin trail
        const roll = Math.random();
        if (roll < 0.16) {
          // Spawn Power-Up Capsule!
          const powerTypes = [
            POWERUP_TYPES.MAGNET,
            POWERUP_TYPES.SHIELD,
            POWERUP_TYPES.BOOST,
            POWERUP_TYPES.DOUBLE
          ];
          const chosenPU = powerTypes[Math.floor(Math.random() * powerTypes.length)];
          this.powerupsList.push({
            lane,
            x: laneX,
            z: spawnZ,
            type: chosenPU,
            jumpY: 18,
            collected: false
          });
        } else if (roll < tier.coinFrequency) {
          // Spawn 3-to-5 coin trail in open track
          const coinCount = Math.floor(Math.random() * 3) + 3;
          for (let c = 0; c < coinCount; c++) {
            this.coinsList.push({
              lane,
              x: laneX,
              z: spawnZ + c * 38,
              jumpY: 0,
              collected: false
            });
          }
        }
      }
    });

    // Tier-adjusted spacing: generous reaction window always preserved
    const spacing = tier.minSpacing + (this.speed / CONFIG.MAX_SPEED) * 110;
    this.nextSpawnZ = spawnZ + spacing + Math.random() * 60;
  }

  // ==========================================================================
  // UPDATE LOOP & PHYSICS
  // ==========================================================================
  update(dt) {
    if (this.hitstopTimer > 0) {
      this.hitstopTimer -= dt;
      return;
    }

    if (this.shakeDuration > 0) {
      this.shakeDuration -= dt;
    }

    if (this.invulnerableTimer > 0) {
      this.invulnerableTimer -= dt;
    }

    this.particles.update(dt);

    // Update ambient clouds & flying cars
    this.clouds.forEach(c => {
      c.x += c.speed * dt;
      if (c.x > this.V_WIDTH + 80) c.x = -c.w - 40;
    });

    this.flyingCars.forEach(car => {
      car.x += car.speed * dt;
      if (car.speed > 0 && car.x > this.V_WIDTH + 80) car.x = -80;
      if (car.speed < 0 && car.x < -80) car.x = this.V_WIDTH + 80;
    });

    if (this.state !== 'playing') {
      this.player.runCycle += dt * 4;
      return;
    }

    this.runTime += dt;
    this.processInputBuffer();

    // 3 Distinct Visual Zones: Zone 1 (Metro 0-40s), Zone 2 (Cyber Tunnel 40-90s), Zone 3 (Skyway 90s+)
    const activeZone = this.runTime < 40 ? ZONES.METRO : (this.runTime < 90 ? ZONES.TUNNEL : ZONES.SKYWAY);
    if (this.currentZone.id !== activeZone.id) {
      this.currentZone = activeZone;
      if (this.hudZoneName) this.hudZoneName.textContent = activeZone.name;
      const zoneKicker = document.querySelector('.hud-zone-kicker');
      const zoneNum = activeZone.id === 'metro' ? 1 : (activeZone.id === 'tunnel' ? 2 : 3);
      if (zoneKicker) zoneKicker.textContent = `ZONE ${zoneNum}`;
      this.showToast('🚀', `${activeZone.name}`, `Entering Zone ${zoneNum}!`, 2200);
      this.audio.playMilestone();
    }

    // Camera & physical feedback decay
    this.landingSquash *= Math.max(0, 1 - 12 * dt);
    this.cameraYOffset *= Math.max(0, 1 - 10 * dt);

    // Check progressive difficulty tier
    const tier = getDifficultyTier(this.runTime);
    if (tier.tier !== this.currentTier) {
      this.currentTier = tier.tier;
    }

    // Update active power-up timers
    if (this.activePowerups.magnet > 0) {
      this.activePowerups.magnet -= dt;
      if (this.activePowerups.magnet <= 0) this.activePowerups.magnet = 0;
    }
    if (this.activePowerups.boost > 0) {
      this.activePowerups.boost -= dt;
      if (this.activePowerups.boost <= 0) this.activePowerups.boost = 0;
    }
    if (this.activePowerups.double > 0) {
      this.activePowerups.double -= dt;
      if (this.activePowerups.double <= 0) this.activePowerups.double = 0;
    }

    // Update combo streak timer & decay
    if (this.comboTimer > 0) {
      this.comboTimer -= dt;
      if (this.comboTimer <= 0) {
        this.comboTimer = 0;
        this.comboCount = 0;
        this.comboMultiplier = 1;
      }
    }

    // Update floating combo text popups
    for (let i = this.floatingCombos.length - 1; i >= 0; i--) {
      const fc = this.floatingCombos[i];
      fc.life -= dt;
      fc.y -= 36 * dt;
      if (fc.life <= 0) {
        this.floatingCombos.splice(i, 1);
      }
    }

    // Determine current speed (boost applies 1.48x multiplier)
    const baseSpeed = calculateSpeed(this.distance) * tier.speedMultiplier;
    this.speed = this.activePowerups.boost > 0 ? baseSpeed * 1.48 : baseSpeed;

    const stepDist = this.speed * dt;
    this.distance += stepDist * 0.05; // 1 unit = 0.05 meters
    this.score = calculateScore(this.distance, this.runCoins);
    this.roadGridOffset = (this.roadGridOffset + stepDist) % 60;

    // Evaluate in-run missions
    const currentStats = {
      coins: this.runCoins,
      time: this.runTime,
      dodged: this.dodgedObstacles
    };

    MISSIONS.forEach(mission => {
      const result = evaluateMission(mission, currentStats);
      if (result.completed && !this.completedMissionsThisRun.has(mission.id)) {
        this.completedMissionsThisRun.add(mission.id);
        this.storage.totalCoins += mission.reward;
        this.saveStorage();
        this.audio.playMissionComplete();
        this.showToast(mission.icon, 'MISSION COMPLETED!', `${mission.title} (+${mission.reward} 🪙)`);
        this.particles.burst(this.player.x, this.roadBottomY - 40, 24, '#00ff88', 200);
      }
    });

    // Check score milestones (1000, 2500, 5000)
    const newMilestones = checkNewMilestones(this.score, this.storage.completedMilestones);
    if (newMilestones.length > 0) {
      newMilestones.forEach(ms => {
        this.storage.completedMilestones.push(ms.id);
        this.storage.totalCoins += ms.reward;
        this.saveStorage();
        this.audio.playMilestone();
        this.showToast(ms.icon, 'MILESTONE ACHIEVED!', `${ms.title} (+${ms.reward} 🪙)`);
        this.particles.burst(this.player.x, this.roadBottomY - 50, 30, '#ffb800', 250);
      });
    }

    // Smooth lane transition (Lerp)
    const targetX = getLaneX(this.player.targetLane, this.V_WIDTH * 0.5, CONFIG.LANE_SPACING);
    this.player.x += (targetX - this.player.x) * Math.min(1, 16 * dt);
    this.player.tilt *= Math.max(0, 1 - 9 * dt);

    // Player Jump Physics
    if (this.player.isJumping) {
      this.player.jumpY += this.player.vy * dt;
      this.player.vy -= 1350 * dt; // gravity

      if (this.player.jumpY <= 0) {
        this.player.jumpY = 0;
        this.player.vy = 0;
        this.player.isJumping = false;
        this.landingSquash = 1.0;
        this.cameraYOffset = 6;
        this.audio.playLanding();
        this.particles.sparks(this.player.x, this.roadBottomY - 5, 8, '#00f3ff');
        this.processInputBuffer();
      }
    }

    // Player Slide Physics
    if (this.player.isSliding) {
      this.player.slideTimer -= dt;
      if (this.player.slideTimer <= 0) {
        this.player.isSliding = false;
        this.processInputBuffer();
      } else {
        if (Math.random() > 0.3) {
          this.particles.sparks(this.player.x, this.roadBottomY - 10, 3, '#ffb800');
        }
      }
    }

    this.player.runCycle += dt * (this.speed / 34);

    // Thruster / Speed trail particles behind runner
    const skin = SKINS[this.storage.skin] || SKINS.classic;
    if (this.activePowerups.boost > 0 || Math.random() > 0.28) {
      const trailY = this.roadBottomY - this.player.jumpY - (this.player.isSliding ? 14 : 32);
      const color = this.activePowerups.boost > 0 ? '#ffb800' : (skin.trailColor || '#00f3ff');
      this.particles.spawn(
        this.player.x + (Math.random() - 0.5) * 14,
        trailY,
        (Math.random() - 0.5) * 35,
        40 + Math.random() * 50,
        0.28,
        3.2,
        color
      );
    }

    // Advance spawn distance
    this.nextSpawnZ -= stepDist;
    if (this.nextSpawnZ <= 920) {
      this.spawnWave();
    }

    // Move and test obstacles
    for (let i = this.obstacles.length - 1; i >= 0; i--) {
      const obs = this.obstacles[i];
      obs.z -= stepDist;

      // Check near-miss reflex evasion
      if (!obs.nearMissEvaluated && this.invulnerableTimer <= 0) {
        if (checkNearMiss(this.player, obs)) {
          obs.nearMissEvaluated = true;
          this.score += 50;
          this.audio.playNearMiss();
          this.shakeCamera(0.08, 2.5);
          this.particles.sparks(this.player.x, this.roadBottomY - 30, 8, '#00f3ff');
          this.showToast('⚡', '+50 NEAR MISS!', 'Close reflex bonus!', 1000);
        }
      }

      // Check collision
      if (this.invulnerableTimer <= 0 && checkCollision(this.player, obs)) {
        if (this.activePowerups.boost > 0) {
          // Boost smashes obstacle!
          this.obstacles.splice(i, 1);
          this.particles.burst(this.player.x, this.roadBottomY - 30, 16, '#ffb800', 180);
          this.score += 150;
          this.dodgedObstacles++;
          this.shakeCamera(0.2, 5);
          continue;
        }

        if (this.activePowerups.shield) {
          // Shield absorbs impact!
          this.activePowerups.shield = false;
          this.invulnerableTimer = 1.2;
          this.hitstopTimer = 0.05;
          this.audio.playShieldBreak();
          this.shakeCamera(0.25, 7);
          this.particles.burst(this.player.x, this.roadBottomY - 40, 20, '#00ff88', 200);
          this.obstacles.splice(i, 1);
          this.dodgedObstacles++;
          // Reset combo streak on obstacle impact
          this.comboCount = 0;
          this.comboMultiplier = 1;
          this.comboTimer = 0;
          continue;
        }

        // Fatal crash
        this.triggerCrash();
        return;
      }

      if (obs.z < this.player.z - 70) {
        this.obstacles.splice(i, 1);
        this.dodgedObstacles++;
      }
    }

    // Move, attract, and test coins
    for (let i = this.coinsList.length - 1; i >= 0; i--) {
      const coin = this.coinsList[i];
      coin.z -= stepDist;

      // Magnet attraction
      if (this.activePowerups.magnet > 0) {
        const dz = coin.z - this.player.z;
        if (dz > -20 && dz < 260) {
          attractCoinTowardPlayer(coin, this.player, dt, 720);
        }
      }

      // Check pickup
      if (checkCoinPickup(this.player, coin)) {
        coin.collected = true;
        const reward = calculateCoinReward(1, this.activePowerups.double > 0);
        this.runCoins += reward;
        this.coins += reward;

        // Combo streak processing
        this.comboCount++;
        this.comboMultiplier = getComboMultiplier(this.comboCount);
        if (this.comboMultiplier > this.highestCombo) {
          this.highestCombo = this.comboMultiplier;
        }
        this.comboTimer = this.comboMaxTimer;

        // Combo score bonus
        this.score += 25 * this.comboMultiplier;

        if (this.comboMultiplier > 1) {
          this.audio.playComboChime(this.comboMultiplier);
        } else {
          this.audio.playCoin();
        }

        const p = this.project(coin.x, coin.z);
        const burstColor = this.activePowerups.double > 0 ? '#ff007f' : '#ffb800';
        this.particles.burst(p.x, p.y - 15 * p.scale, 8, burstColor, 120);

        // Spawn floating combo label if streak >= 3
        if (this.comboCount >= 3) {
          const comboText = `+${reward}🪙 x${this.comboMultiplier}!`;
          this.floatingCombos.push({
            x: p.x,
            y: p.y - 25 * p.scale,
            text: comboText,
            life: 0.9,
            maxLife: 0.9,
            color: this.comboMultiplier >= 5 ? '#ff007f' : (this.comboMultiplier >= 3 ? '#ffb800' : '#00f3ff')
          });
        }

        this.coinsList.splice(i, 1);
        continue;
      }

      if (coin.z < this.player.z - 50) {
        this.coinsList.splice(i, 1);
      }
    }

    // Move and test power-ups
    for (let i = this.powerupsList.length - 1; i >= 0; i--) {
      const pu = this.powerupsList[i];
      pu.z -= stepDist;

      if (checkPowerupPickup(this.player, pu)) {
        pu.collected = true;
        this.audio.playPowerup();
        const p = this.project(pu.x, pu.z);
        this.particles.burst(p.x, p.y - 20 * p.scale, 16, '#00ff88', 160);

        if (pu.type === POWERUP_TYPES.MAGNET) {
          this.activePowerups.magnet = 8.5; // 8.5s magnet
          this.showToast('🧲', 'MAGNET ACTIVE!', 'Attracting nearby coins for 8s!', 2000);
        } else if (pu.type === POWERUP_TYPES.SHIELD) {
          this.activePowerups.shield = true;
          this.showToast('🛡️', 'SHIELD EQUIPPED!', 'Protected from 1 collision!', 2000);
        } else if (pu.type === POWERUP_TYPES.BOOST) {
          this.activePowerups.boost = 4.5; // 4.5s boost dash
          this.showToast('⚡', 'SPEED BOOST!', 'Hyperspeed obstacle smash for 4.5s!', 2000);
        } else if (pu.type === POWERUP_TYPES.DOUBLE) {
          this.activePowerups.double = 8.5; // 8.5s double coins
          this.showToast('🪙', '2X COINS ACTIVE!', 'Double coin rewards for 8.5s!', 2000);
        }

        this.powerupsList.splice(i, 1);
        continue;
      }

      if (pu.z < this.player.z - 50) {
        this.powerupsList.splice(i, 1);
      }
    }

    this.updateHUD();
  }

  shakeCamera(duration = 0.35, intensity = 8) {
    this.shakeDuration = duration;
    this.shakeIntensity = intensity;
  }

  triggerCrash() {
    this.hitstopTimer = 0.08;
    this.shakeCamera(0.45, 12);
    this.audio.playCrash();
    this.particles.burst(this.player.x, this.roadBottomY - 40, 24, '#ff0044', 220);

    // Reset combo streak on crash
    this.comboCount = 0;
    this.comboMultiplier = 1;
    this.comboTimer = 0;

    if (!this.hasRevivedThisRun) {
      this.showReviveModal();
    } else {
      this.setState('gameover');
    }
  }

  updateHUD() {
    this.hudScore.textContent = this.score.toLocaleString();
    this.hudCoins.textContent = this.runCoins.toString();
    this.hudDistance.textContent = `${Math.floor(this.distance)}m`;
    this.hudBestChip.textContent = Math.max(this.score, this.storage.bestScore).toLocaleString();

    const spdFactor = (this.speed / CONFIG.BASE_SPEED).toFixed(1);
    this.hudSpeedVal.textContent = `${spdFactor}x`;

    // Active Mission Chip
    if (this.hudMissionChip) {
      const currentStats = {
        coins: this.runCoins,
        time: this.runTime,
        dodged: this.dodgedObstacles
      };
      const activeMission = MISSIONS.find(m => !this.completedMissionsThisRun.has(m.id)) || MISSIONS[0];
      const evalResult = evaluateMission(activeMission, currentStats);
      if (this.hudMissionIcon) this.hudMissionIcon.textContent = activeMission.icon;
      if (this.hudMissionTitle) {
        if (evalResult.completed) {
          this.hudMissionTitle.textContent = `${activeMission.title}: DONE!`;
        } else {
          this.hudMissionTitle.textContent = `${activeMission.title}: ${evalResult.progress}/${evalResult.target}`;
        }
      }
      if (this.hudMissionFill) {
        this.hudMissionFill.style.width = `${evalResult.completed ? 100 : evalResult.percentage}%`;
      }
    }

    // Combo Streak Indicator
    if (this.hudComboChip) {
      if (this.comboCount >= 3 && this.comboTimer > 0) {
        this.hudComboChip.style.display = 'flex';
        if (this.hudComboMult) {
          this.hudComboMult.textContent = `x${this.comboMultiplier}`;
          this.hudComboMult.classList.toggle('high', this.comboMultiplier >= 5);
        }
        if (this.hudComboFill) {
          const comboPct = Math.max(0, Math.min(100, (this.comboTimer / this.comboMaxTimer) * 100));
          this.hudComboFill.style.width = `${comboPct}%`;
        }
      } else {
        this.hudComboChip.style.display = 'none';
      }
    }

    // Power-up indicators with clean countdown timers
    if (this.activePowerups.magnet > 0) {
      this.puMagnet.style.display = 'flex';
      const pct = (this.activePowerups.magnet / 8.5) * 100;
      this.meterMagnet.style.width = `${pct}%`;
      if (this.timeMagnet) this.timeMagnet.textContent = `${Math.ceil(this.activePowerups.magnet)}s`;
    } else {
      this.puMagnet.style.display = 'none';
    }

    if (this.activePowerups.shield) {
      this.puShield.style.display = 'flex';
      this.meterShield.style.width = '100%';
    } else {
      this.puShield.style.display = 'none';
    }

    if (this.activePowerups.boost > 0) {
      this.puBoost.style.display = 'flex';
      const pct = (this.activePowerups.boost / 4.5) * 100;
      this.meterBoost.style.width = `${pct}%`;
      if (this.timeBoost) this.timeBoost.textContent = `${Math.ceil(this.activePowerups.boost)}s`;
    } else {
      this.puBoost.style.display = 'none';
    }

    if (this.activePowerups.double > 0) {
      if (this.puDouble) this.puDouble.style.display = 'flex';
      const pct = (this.activePowerups.double / 8.5) * 100;
      if (this.meterDouble) this.meterDouble.style.width = `${pct}%`;
      if (this.timeDouble) this.timeDouble.textContent = `${Math.ceil(this.activePowerups.double)}s`;
    } else {
      if (this.puDouble) this.puDouble.style.display = 'none';
    }
  }

  // ==========================================================================
  // 3D PERSPECTIVE PROJECTION
  // ==========================================================================
  project(worldX, worldZ) {
    const relZ = Math.max(1, worldZ - this.player.z);
    const maxZ = 850;
    const normZ = Math.min(1, relZ / maxZ);

    const persp = 1 / (1 + relZ / this.cameraDepth);
    const y = this.horizonY + (this.roadBottomY - this.horizonY) * Math.pow(1 - normZ, 1.4);
    const roadWidthAtZ = this.roadTopWidth + (this.roadBottomWidth - this.roadTopWidth) * Math.pow(1 - normZ, 1.4);

    const laneOffsetFromCenter = (worldX - this.V_WIDTH * 0.5) / (this.roadBottomWidth * 0.5);
    const x = this.V_WIDTH * 0.5 + laneOffsetFromCenter * (roadWidthAtZ * 0.5);

    return {
      x,
      y,
      scale: Math.max(0.08, Math.min(1.0, persp * 1.55)),
      roadWidthAtZ,
      normZ
    };
  }

  // ==========================================================================
  // RENDERING ENGINE (Atmosphere, Railway, Obstacles, Runner, FX)
  // ==========================================================================
  render() {
    const ctx = this.ctx;
    ctx.save();
    ctx.scale(this.scaleX, this.scaleY);

    // Clean canvas background fill
    ctx.fillStyle = '#050711';
    ctx.fillRect(0, 0, this.V_WIDTH, this.V_HEIGHT);

    // Camera Shake & Landing Feedback
    let ox = 0;
    let oy = this.cameraYOffset;
    if (this.shakeDuration > 0) {
      const decay = this.shakeDuration / 0.45;
      ox += (Math.random() - 0.5) * this.shakeIntensity * decay;
      oy += (Math.random() - 0.5) * this.shakeIntensity * decay;
    }
    if (ox !== 0 || oy !== 0) {
      ctx.translate(ox, oy);
    }

    // 1. Atmosphere: Sky, Clouds, Horizon Sun, City Buildings, Hovercars
    this.renderAtmosphere(ctx);

    // 2. Railway Track: Rails, Sleepers, Ballast, Bridges, Signals
    this.renderRailwayTracks(ctx);

    // 3. Dynamic Entities: Trains, Hurdles, Gantries, Powerups, Coins
    this.renderEntities(ctx);

    // 4. Hero Player: Cartoon 3D Runner (Hoodie, Backpack, Sneakers)
    this.renderPlayer(ctx);

    // 5. Particles: Sparks, FX, Boost fire
    this.particles.render(ctx);

    // 6. Floating Combo Text Popups (+x2!, +x3!, etc.)
    this.renderFloatingCombos(ctx);

    ctx.restore();
  }

  renderFloatingCombos(ctx) {
    if (!this.floatingCombos || this.floatingCombos.length === 0) return;
    ctx.save();
    for (let i = 0; i < this.floatingCombos.length; i++) {
      const fc = this.floatingCombos[i];
      const alpha = Math.max(0, Math.min(1, fc.life / fc.maxLife));
      ctx.globalAlpha = alpha;
      ctx.font = '900 17px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = fc.color;
      ctx.shadowColor = fc.color;
      ctx.shadowBlur = 10;
      ctx.fillText(fc.text, fc.x, fc.y);
    }
    ctx.restore();
  }

  renderAtmosphere(ctx) {
    const zoneId = this.currentZone?.id || 'metro';

    if (zoneId === 'metro') {
      // ======================================================================
      // ZONE 1: NEON METRO — Cyberpunk Skyline, Synthwave Sun & Hovercars
      // ======================================================================
      const skyGrad = ctx.createLinearGradient(0, 0, 0, this.horizonY);
      skyGrad.addColorStop(0, '#040612');
      skyGrad.addColorStop(0.4, '#0d1330');
      skyGrad.addColorStop(0.75, '#1e1b4b');
      skyGrad.addColorStop(1, '#3b0764');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, this.V_WIDTH, this.horizonY);

      // Clouds
      this.clouds.forEach(c => {
        ctx.save();
        ctx.fillStyle = `rgba(168, 85, 247, ${c.opacity})`;
        ctx.beginPath();
        ctx.ellipse(c.x, c.y, c.w * 0.5, c.h * 0.5, 0, 0, Math.PI * 2);
        ctx.ellipse(c.x + c.w * 0.25, c.y - c.h * 0.2, c.w * 0.35, c.h * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Synthwave Sun / Distant Radiant Core at Horizon
      const sunRadius = 68;
      const sunGrad = ctx.createRadialGradient(
        this.V_WIDTH * 0.5,
        this.horizonY - 10,
        10,
        this.V_WIDTH * 0.5,
        this.horizonY - 10,
        sunRadius
      );
      sunGrad.addColorStop(0, 'rgba(255, 220, 100, 0.95)');
      sunGrad.addColorStop(0.45, 'rgba(255, 0, 128, 0.85)');
      sunGrad.addColorStop(1, 'rgba(255, 0, 128, 0)');

      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(this.V_WIDTH * 0.5, this.horizonY - 10, sunRadius, 0, Math.PI * 2);
      ctx.fill();

      // Horizontal Sun Segment Lines
      ctx.fillStyle = '#0f172a';
      for (let s = -sunRadius + 14; s < sunRadius; s += 8) {
        const lineY = this.horizonY - 10 + s;
        if (lineY < this.horizonY && lineY > this.horizonY - 10) {
          ctx.fillRect(this.V_WIDTH * 0.5 - sunRadius, lineY, sunRadius * 2, 2.5);
        }
      }

      // Distant City Skyscrapers with Glowing Windows
      this.cityBuildings.forEach(b => {
        const by = this.horizonY - b.h;
        ctx.fillStyle = '#070b1a';
        ctx.fillRect(b.x, by, b.w, b.h);

        // Building top neon rim
        ctx.fillStyle = b.hue;
        ctx.fillRect(b.x, by, b.w, 2);

        // Illuminated Windows
        ctx.fillStyle = b.hue;
        ctx.globalAlpha = 0.5;
        for (let r = 0; r < b.windows; r++) {
          for (let c = 0; c < 2; c++) {
            ctx.fillRect(b.x + 4 + c * (b.w - 12), by + 10 + r * 16, 4, 6);
          }
        }
        ctx.globalAlpha = 1.0;

        // Hologram Sign
        if (b.billboard) {
          ctx.fillStyle = b.hue;
          ctx.font = '900 9px system-ui, sans-serif';
          ctx.textAlign = 'center';
          ctx.fillText(b.billboard, b.x + b.w * 0.5, by + 18);
        }
      });

      // Flying Hovercars
      this.flyingCars.forEach(car => {
        ctx.save();
        ctx.fillStyle = car.color;
        ctx.shadowColor = car.color;
        ctx.shadowBlur = 8;
        ctx.fillRect(car.x, car.y, car.len, 2.5);

        const trail = ctx.createLinearGradient(car.x - (car.speed > 0 ? 30 : -30), car.y, car.x, car.y);
        trail.addColorStop(0, 'rgba(0, 243, 255, 0)');
        trail.addColorStop(1, car.color);
        ctx.fillStyle = trail;
        ctx.fillRect(car.x - (car.speed > 0 ? 30 : -car.len), car.y, 30, 2);
        ctx.restore();
      });

      // Horizon Fog
      const fogGrad = ctx.createLinearGradient(0, this.horizonY - 6, 0, this.horizonY + 20);
      fogGrad.addColorStop(0, 'rgba(59, 7, 100, 0)');
      fogGrad.addColorStop(0.5, 'rgba(255, 0, 128, 0.45)');
      fogGrad.addColorStop(1, 'rgba(10, 14, 30, 0.95)');
      ctx.fillStyle = fogGrad;
      ctx.fillRect(0, this.horizonY - 6, this.V_WIDTH, 26);

    } else if (zoneId === 'tunnel') {
      // ======================================================================
      // ZONE 2: CYBER TUNNEL — Hexagonal Subterranean Laser Conduit
      // ======================================================================
      const tunnelSky = ctx.createLinearGradient(0, 0, 0, this.horizonY);
      tunnelSky.addColorStop(0, '#020008');
      tunnelSky.addColorStop(0.5, '#0b0217');
      tunnelSky.addColorStop(1, '#18042b');
      ctx.fillStyle = tunnelSky;
      ctx.fillRect(0, 0, this.V_WIDTH, this.horizonY);

      // Distant Tunnel Core Aperture
      const coreGrad = ctx.createRadialGradient(
        this.V_WIDTH * 0.5, this.horizonY - 2, 4,
        this.V_WIDTH * 0.5, this.horizonY - 2, 54
      );
      coreGrad.addColorStop(0, '#00ff88');
      coreGrad.addColorStop(0.35, 'rgba(168, 85, 247, 0.6)');
      coreGrad.addColorStop(1, 'rgba(2, 0, 8, 0)');
      ctx.fillStyle = coreGrad;
      ctx.beginPath();
      ctx.arc(this.V_WIDTH * 0.5, this.horizonY - 2, 54, 0, Math.PI * 2);
      ctx.fill();

      // Ceiling Laser Power Conduits (pulsing emerald & violet)
      const conduitCount = 5;
      for (let i = 0; i < conduitCount; i++) {
        const cx = (i / (conduitCount - 1)) * this.V_WIDTH;
        ctx.strokeStyle = i % 2 === 0 ? 'rgba(0, 255, 136, 0.4)' : 'rgba(168, 85, 247, 0.45)';
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(cx, 0);
        ctx.lineTo(this.V_WIDTH * 0.5, this.horizonY - 5);
        ctx.stroke();
      }

      // Animated Subterranean Warning Hologram
      ctx.fillStyle = 'rgba(0, 255, 136, 0.85)';
      ctx.font = '900 11px system-ui, sans-serif';
      ctx.textAlign = 'center';
      ctx.shadowColor = '#00ff88';
      ctx.shadowBlur = 10;
      ctx.fillText('⚡ CYBER TUNNEL // CORE SECTOR 02 ⚡', this.V_WIDTH * 0.5, 42);
      ctx.shadowBlur = 0;

      // Hexagonal Enclosure Arches rushing overhead
      const archCount = 5;
      for (let a = 0; a < archCount; a++) {
        const aZ = (a * 170 - this.roadGridOffset + 850) % 850;
        const proj = this.project(this.V_WIDTH * 0.5, this.player.z + aZ);
        const s = proj.scale;
        if (s > 0.12) {
          const archW = proj.roadWidthAtZ * 1.35;
          const archH = 125 * s;
          const topArchY = proj.y - archH;

          ctx.strokeStyle = (a % 2 === 0) ? 'rgba(0, 255, 136, 0.7)' : 'rgba(168, 85, 247, 0.75)';
          ctx.lineWidth = 3.5 * s;
          ctx.beginPath();
          ctx.moveTo(proj.x - archW * 0.5, proj.y);
          ctx.lineTo(proj.x - archW * 0.45, topArchY + archH * 0.35);
          ctx.lineTo(proj.x - archW * 0.25, topArchY);
          ctx.lineTo(proj.x + archW * 0.25, topArchY);
          ctx.lineTo(proj.x + archW * 0.45, topArchY + archH * 0.35);
          ctx.lineTo(proj.x + archW * 0.5, proj.y);
          ctx.stroke();
        }
      }

    } else {
      // ======================================================================
      // ZONE 3: SKYWAY — Orbital Suspended Cosmos & Nebula Vista
      // ======================================================================
      const spaceSky = ctx.createLinearGradient(0, 0, 0, this.horizonY);
      spaceSky.addColorStop(0, '#010006');
      spaceSky.addColorStop(0.4, '#080214');
      spaceSky.addColorStop(0.75, '#1e0538');
      spaceSky.addColorStop(1, '#3b0642');
      ctx.fillStyle = spaceSky;
      ctx.fillRect(0, 0, this.V_WIDTH, this.horizonY);

      // Twinkling Starfield
      this.stars.forEach(st => {
        const alpha = 0.35 + 0.5 * Math.sin(performance.now() * 0.002 * st.blinkSpeed + st.blinkOffset);
        ctx.fillStyle = st.color;
        ctx.globalAlpha = Math.max(0.1, alpha);
        ctx.fillRect(st.x, st.y, st.size, st.size);
      });
      ctx.globalAlpha = 1.0;

      // Colossal Orbital Ringed Planet on the Horizon
      const planetX = this.V_WIDTH * 0.72;
      const planetY = this.horizonY - 45;
      const planetR = 48;

      const pGrad = ctx.createRadialGradient(planetX - 12, planetY - 12, 6, planetX, planetY, planetR);
      pGrad.addColorStop(0, '#ffe066');
      pGrad.addColorStop(0.4, '#ff6b00');
      pGrad.addColorStop(0.85, '#990033');
      pGrad.addColorStop(1, '#2b001a');
      ctx.fillStyle = pGrad;
      ctx.beginPath();
      ctx.arc(planetX, planetY, planetR, 0, Math.PI * 2);
      ctx.fill();

      // Planetary Ring
      ctx.save();
      ctx.translate(planetX, planetY);
      ctx.rotate(-0.35);
      ctx.strokeStyle = 'rgba(255, 184, 0, 0.65)';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.ellipse(0, 0, planetR * 1.85, planetR * 0.35, 0, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // Radiant Solar Plasma Horizon Glow
      const plasmaGrad = ctx.createLinearGradient(0, this.horizonY - 14, 0, this.horizonY + 16);
      plasmaGrad.addColorStop(0, 'rgba(255, 184, 0, 0)');
      plasmaGrad.addColorStop(0.5, 'rgba(255, 102, 0, 0.45)');
      plasmaGrad.addColorStop(1, 'rgba(10, 4, 24, 0.95)');
      ctx.fillStyle = plasmaGrad;
      ctx.fillRect(0, this.horizonY - 14, this.V_WIDTH, 30);
    }
  }

  renderRailwayTracks(ctx) {
    const zoneId = this.currentZone?.id || 'metro';
    const topLeftX = this.V_WIDTH * 0.5 - this.roadTopWidth * 0.5;
    const topRightX = this.V_WIDTH * 0.5 + this.roadTopWidth * 0.5;
    const bottomLeftX = this.V_WIDTH * 0.5 - this.roadBottomWidth * 0.5;
    const bottomRightX = this.V_WIDTH * 0.5 + this.roadBottomWidth * 0.5;

    // 1. Track Bed Ballast
    const ballastGrad = ctx.createLinearGradient(0, this.horizonY, 0, this.roadBottomY);
    if (zoneId === 'metro') {
      ballastGrad.addColorStop(0, '#060a17');
      ballastGrad.addColorStop(0.5, '#0b1126');
      ballastGrad.addColorStop(1, '#111836');
    } else if (zoneId === 'tunnel') {
      ballastGrad.addColorStop(0, '#080514');
      ballastGrad.addColorStop(0.5, '#0e0924');
      ballastGrad.addColorStop(1, '#150f33');
    } else {
      ballastGrad.addColorStop(0, '#050310');
      ballastGrad.addColorStop(0.5, '#120824');
      ballastGrad.addColorStop(1, '#1f0d36');
    }

    ctx.fillStyle = ballastGrad;
    ctx.beginPath();
    ctx.moveTo(topLeftX, this.horizonY);
    ctx.lineTo(topRightX, this.horizonY);
    ctx.lineTo(bottomRightX, this.roadBottomY + 70);
    ctx.lineTo(bottomLeftX, this.roadBottomY + 70);
    ctx.closePath();
    ctx.fill();

    // 2. Railway Sleepers / Energy Grid Strips
    const sleeperCount = 18;
    for (let i = 0; i < sleeperCount; i++) {
      const z = (i * 48 - this.roadGridOffset + 850) % 850;
      const proj = this.project(this.V_WIDTH * 0.5, this.player.z + z);
      const halfW = proj.roadWidthAtZ * 0.48;
      const sleeperH = Math.max(2, 6 * proj.scale);

      if (zoneId === 'metro') {
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(proj.x - halfW, proj.y - sleeperH * 0.5, halfW * 2, sleeperH);
        ctx.fillStyle = '#334155';
        ctx.fillRect(proj.x - halfW, proj.y - sleeperH * 0.5, halfW * 2, Math.max(1, sleeperH * 0.35));
      } else if (zoneId === 'tunnel') {
        ctx.fillStyle = '#1e1b4b';
        ctx.fillRect(proj.x - halfW, proj.y - sleeperH * 0.5, halfW * 2, sleeperH);
        ctx.fillStyle = '#00ff88';
        ctx.fillRect(proj.x - halfW, proj.y - sleeperH * 0.5, 6 * proj.scale, sleeperH);
        ctx.fillRect(proj.x + halfW - 6 * proj.scale, proj.y - sleeperH * 0.5, 6 * proj.scale, sleeperH);
      } else {
        ctx.fillStyle = '#3b1c04';
        ctx.fillRect(proj.x - halfW, proj.y - sleeperH * 0.5, halfW * 2, sleeperH);
        ctx.fillStyle = '#ffb800';
        ctx.fillRect(proj.x - halfW * 0.6, proj.y - sleeperH * 0.25, halfW * 1.2, Math.max(1, sleeperH * 0.4));
      }
    }

    // 3. Three Pairs of Steel / Energy Railway Rails
    const laneCenters = [
      -CONFIG.LANE_SPACING, // Left lane
      0,                    // Center lane
      CONFIG.LANE_SPACING   // Right lane
    ];

    const railGauge = 34;

    laneCenters.forEach((laneXOff, idx) => {
      const leftRailX = this.V_WIDTH * 0.5 + laneXOff - railGauge * 0.5;
      const rightRailX = this.V_WIDTH * 0.5 + laneXOff + railGauge * 0.5;

      const pTopL = this.project(leftRailX, this.player.z + 850);
      const pBotL = this.project(leftRailX, this.player.z);
      const pTopR = this.project(rightRailX, this.player.z + 850);
      const pBotR = this.project(rightRailX, this.player.z);

      // Base Rail Shadow
      ctx.strokeStyle = '#090d1f';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(pTopL.x, pTopL.y);
      ctx.lineTo(pBotL.x, pBotL.y + 70);
      ctx.moveTo(pTopR.x, pTopR.y);
      ctx.lineTo(pBotR.x, pBotR.y + 70);
      ctx.stroke();

      // Specular Rail Head
      let railColor;
      if (zoneId === 'metro') {
        railColor = idx === 0 ? '#00f3ff' : (idx === 1 ? '#e2e8f0' : '#ff007f');
      } else if (zoneId === 'tunnel') {
        railColor = idx === 0 ? '#00ff88' : (idx === 1 ? '#e0e7ff' : '#a855f7');
      } else {
        railColor = idx === 0 ? '#ffb800' : (idx === 1 ? '#ffffff' : '#ff7700');
      }

      ctx.strokeStyle = railColor;
      ctx.lineWidth = 2.4;
      ctx.beginPath();
      ctx.moveTo(pTopL.x, pTopL.y);
      ctx.lineTo(pBotL.x, pBotL.y + 70);
      ctx.moveTo(pTopR.x, pTopR.y);
      ctx.lineTo(pBotR.x, pBotR.y + 70);
      ctx.stroke();
    });

    // 4. Side Guardrails & Laser Containment Fields
    ctx.lineWidth = 3;
    let leftGlow = '#00f3ff';
    let rightGlow = '#ff007f';

    if (zoneId === 'tunnel') {
      leftGlow = '#00ff88';
      rightGlow = '#a855f7';
    } else if (zoneId === 'skyway') {
      leftGlow = '#ffb800';
      rightGlow = '#ff6600';
    }

    ctx.strokeStyle = leftGlow;
    ctx.shadowColor = leftGlow;
    ctx.shadowBlur = 10;
    ctx.beginPath();
    ctx.moveTo(topLeftX, this.horizonY);
    ctx.lineTo(bottomLeftX, this.roadBottomY + 70);
    ctx.stroke();

    ctx.strokeStyle = rightGlow;
    ctx.shadowColor = rightGlow;
    ctx.beginPath();
    ctx.moveTo(topRightX, this.horizonY);
    ctx.lineTo(bottomRightX, this.roadBottomY + 70);
    ctx.stroke();
    ctx.shadowBlur = 0;

    // 5. Zone Structural Landmarks (Catenary Masts or Skyway Pylons)
    if (zoneId === 'metro' || zoneId === 'tunnel') {
      const poleCount = 6;
      for (let p = 0; p < poleCount; p++) {
        const pZ = (p * 140 - this.roadGridOffset + 850) % 850;
        const leftP = this.project(this.V_WIDTH * 0.5 - CONFIG.LANE_SPACING * 1.6, this.player.z + pZ);
        const rightP = this.project(this.V_WIDTH * 0.5 + CONFIG.LANE_SPACING * 1.6, this.player.z + pZ);
        const scale = leftP.scale;
        const poleH = 65 * scale;
        const poleW = 6 * scale;

        ctx.fillStyle = '#1e293b';
        ctx.fillRect(leftP.x - poleW * 0.5, leftP.y - poleH, poleW, poleH);
        ctx.fillRect(leftP.x, leftP.y - poleH, 18 * scale, 3 * scale);
        ctx.fillStyle = leftGlow;
        ctx.fillRect(leftP.x + 16 * scale, leftP.y - poleH - 2 * scale, 4 * scale, 4 * scale);

        ctx.fillStyle = '#1e293b';
        ctx.fillRect(rightP.x - poleW * 0.5, rightP.y - poleH, poleW, poleH);
        ctx.fillRect(rightP.x - 18 * scale, rightP.y - poleH, 18 * scale, 3 * scale);
        ctx.fillStyle = rightGlow;
        ctx.fillRect(rightP.x - 20 * scale, rightP.y - poleH - 2 * scale, 4 * scale, 4 * scale);
      }
    } else {
      // Skyway: Suspended Structural Support Pylons descending downward
      const pylonCount = 4;
      for (let py = 0; py < pylonCount; py++) {
        const pyZ = (py * 210 - this.roadGridOffset + 850) % 850;
        const proj = this.project(this.V_WIDTH * 0.5, this.player.z + pyZ);
        const s = proj.scale;
        if (s > 0.15) {
          ctx.fillStyle = '#261204';
          ctx.fillRect(proj.x - 8 * s, proj.y, 16 * s, 60 * s);
          ctx.fillStyle = '#ffb800';
          ctx.fillRect(proj.x - 3 * s, proj.y, 6 * s, 60 * s);
        }
      }
    }
  }

  renderEntities(ctx) {
    // Sort all obstacles, coins, and powerups by distance Z descending (draw farthest first)
    const entities = [
      ...this.obstacles.map(o => ({ ...o, kind: 'obstacle' })),
      ...this.coinsList.map(c => ({ ...c, kind: 'coin' })),
      ...this.powerupsList.map(p => ({ ...p, kind: 'powerup' }))
    ];

    entities.sort((a, b) => b.z - a.z);

    entities.forEach(ent => {
      if (ent.kind === 'obstacle') {
        this.renderObstacle(ctx, ent);
      } else if (ent.kind === 'coin') {
        this.renderCoin(ctx, ent);
      } else if (ent.kind === 'powerup') {
        this.renderPowerup(ctx, ent);
      }
    });
  }

  renderObstacle(ctx, obs) {
    const proj = this.project(obs.x, obs.z);
    const scale = proj.scale;
    if (scale <= 0.08) return;

    ctx.save();
    ctx.translate(proj.x, proj.y);

    switch (obs.type) {
      case OBSTACLE_TYPES.TRAIN: {
        // ====================================================================
        // SUBWAY / RAILWAY TRAIN CAR (Solid Obstacle: Must Dodge!)
        // ====================================================================
        const trainW = 76 * scale;
        const trainH = 110 * scale;

        // Drop shadow onto tracks
        ctx.fillStyle = 'rgba(0, 0, 0, 0.75)';
        ctx.beginPath();
        ctx.ellipse(0, 2, trainW * 0.55, 12 * scale, 0, 0, Math.PI * 2);
        ctx.fill();

        // Train Car Body (Front Face)
        const bodyGrad = ctx.createLinearGradient(-trainW * 0.5, -trainH, trainW * 0.5, 0);
        bodyGrad.addColorStop(0, '#1e293b');
        bodyGrad.addColorStop(0.5, '#0f172a');
        bodyGrad.addColorStop(1, '#090d1a');

        ctx.fillStyle = bodyGrad;
        ctx.beginPath();
        ctx.roundRect(-trainW * 0.5, -trainH, trainW, trainH, 10 * scale);
        ctx.fill();

        // Train Front Cab Windshield (Tinted Cyan Glass)
        ctx.fillStyle = '#00f3ff';
        ctx.shadowColor = '#00f3ff';
        ctx.shadowBlur = 12 * scale;
        ctx.beginPath();
        ctx.roundRect(-trainW * 0.4, -trainH + 16 * scale, trainW * 0.8, 32 * scale, 6 * scale);
        ctx.fill();

        // Windshield glare reflection
        ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
        ctx.fillRect(-trainW * 0.35, -trainH + 20 * scale, trainW * 0.4, 4 * scale);

        // Twin Front Train Headlights (High-intensity beams)
        ctx.fillStyle = '#ffb800';
        ctx.shadowColor = '#ffb800';
        ctx.shadowBlur = 16 * scale;
        ctx.beginPath();
        ctx.arc(-trainW * 0.3, -24 * scale, 7 * scale, 0, Math.PI * 2);
        ctx.arc(trainW * 0.3, -24 * scale, 7 * scale, 0, Math.PI * 2);
        ctx.fill();

        // Train Cowcatcher / Fender Grill (Hazard Stripes)
        ctx.fillStyle = '#ff0044';
        ctx.fillRect(-trainW * 0.45, -12 * scale, trainW * 0.9, 10 * scale);
        ctx.fillStyle = '#ffffff';
        for (let s = -trainW * 0.4; s < trainW * 0.4; s += 12 * scale) {
          ctx.fillRect(s, -12 * scale, 4 * scale, 10 * scale);
        }

        ctx.shadowBlur = 0;
        break;
      }

      case OBSTACLE_TYPES.BARRIER:
      case OBSTACLE_TYPES.HURDLE: {
        // ====================================================================
        // RAILWAY HURDLE / BARRIER GATE (Must Jump Over!)
        // ====================================================================
        const barrierW = 82 * scale;
        const barrierH = 38 * scale;

        // Ground shadow
        ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
        ctx.beginPath();
        ctx.ellipse(0, 2, barrierW * 0.52, 6 * scale, 0, 0, Math.PI * 2);
        ctx.fill();

        // Side Support Legs
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-barrierW * 0.5, -barrierH, 8 * scale, barrierH);
        ctx.fillRect(barrierW * 0.5 - 8 * scale, -barrierH, 8 * scale, barrierH);

        // Crossbeam with Red/White or Yellow/Black Hazard Stripes
        ctx.fillStyle = '#ff007f';
        ctx.fillRect(-barrierW * 0.5, -barrierH + 6 * scale, barrierW, 16 * scale);

        ctx.fillStyle = '#ffffff';
        for (let s = -barrierW * 0.5; s < barrierW * 0.5; s += 16 * scale) {
          ctx.beginPath();
          ctx.moveTo(s, -barrierH + 6 * scale);
          ctx.lineTo(s + 8 * scale, -barrierH + 6 * scale);
          ctx.lineTo(s + 4 * scale, -barrierH + 22 * scale);
          ctx.lineTo(s - 4 * scale, -barrierH + 22 * scale);
          ctx.closePath();
          ctx.fill();
        }

        // Flashing Warning Light on top
        ctx.fillStyle = '#00f3ff';
        ctx.shadowColor = '#00f3ff';
        ctx.shadowBlur = 10 * scale;
        ctx.beginPath();
        ctx.arc(0, -barrierH - 2 * scale, 4 * scale, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;
      }

      case OBSTACLE_TYPES.OVERHEAD:
      case OBSTACLE_TYPES.LASER: {
        // ====================================================================
        // LOW TUNNEL / BRIDGE GANTRY / LASER (Must Slide / Roll Under!)
        // ====================================================================
        const beamW = 86 * scale;
        const totalH = 78 * scale;
        const clearanceH = 36 * scale; // Area open underneath to slide

        // Tall side support pillars
        ctx.fillStyle = '#0f172a';
        ctx.fillRect(-beamW * 0.5, -totalH, 8 * scale, totalH);
        ctx.fillRect(beamW * 0.5 - 8 * scale, -totalH, 8 * scale, totalH);

        // Low Overhead Horizontal Crossbar
        ctx.fillStyle = '#090d1a';
        ctx.fillRect(-beamW * 0.5, -totalH, beamW, totalH - clearanceH);

        // Glowing Low Plasma Conduit / Warning Strip
        ctx.fillStyle = '#00f3ff';
        ctx.shadowColor = '#00f3ff';
        ctx.shadowBlur = 14 * scale;
        ctx.fillRect(-beamW * 0.5, -clearanceH - 6 * scale, beamW, 7 * scale);
        ctx.shadowBlur = 0;

        // Slide arrow label
        if (scale > 0.38) {
          ctx.fillStyle = '#00f3ff';
          ctx.font = `900 ${Math.round(11 * scale)}px system-ui, sans-serif`;
          ctx.textAlign = 'center';
          ctx.fillText('▼ SLIDE', 0, -clearanceH - 12 * scale);
        }
        break;
      }

      case OBSTACLE_TYPES.CRATE:
      case OBSTACLE_TYPES.PILLAR:
      default: {
        // ====================================================================
        // RAILWAY CARGO CRATE / SOLID MONOLITH (Must Dodge!)
        // ====================================================================
        const crateW = 66 * scale;
        const crateH = 64 * scale;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
        ctx.beginPath();
        ctx.ellipse(0, 2, crateW * 0.52, 8 * scale, 0, 0, Math.PI * 2);
        ctx.fill();

        // Crate Body (Industrial Wood / Metal Container)
        ctx.fillStyle = '#78350f';
        ctx.fillRect(-crateW * 0.5, -crateH, crateW, crateH);

        // Corner Steel Brackets & Cross Bracing
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 3 * scale;
        ctx.strokeRect(-crateW * 0.5, -crateH, crateW, crateH);

        ctx.beginPath();
        ctx.moveTo(-crateW * 0.5, -crateH);
        ctx.lineTo(crateW * 0.5, 0);
        ctx.moveTo(crateW * 0.5, -crateH);
        ctx.lineTo(-crateW * 0.5, 0);
        ctx.stroke();

        // Neon warning tag
        ctx.fillStyle = '#f59e0b';
        ctx.shadowColor = '#f59e0b';
        ctx.shadowBlur = 8 * scale;
        ctx.beginPath();
        ctx.arc(0, -crateH * 0.5, 5 * scale, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
        break;
      }
    }

    ctx.restore();
  }

  renderCoin(ctx, coin) {
    const proj = this.project(coin.x, coin.z);
    const scale = proj.scale;
    if (scale <= 0.08) return;

    ctx.save();
    const coinY = proj.y - (coin.jumpY || 0) * scale;
    ctx.translate(proj.x, coinY);

    // Dynamic 3D spinning rotation
    const spin = performance.now() * 0.005 + coin.x * 0.1;
    const spinWidth = Math.cos(spin);
    const r = 16 * scale;

    // Ground shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.5)';
    ctx.beginPath();
    ctx.ellipse(0, (coin.jumpY || 0) * scale + 2, r * Math.abs(spinWidth), 4 * scale, 0, 0, Math.PI * 2);
    ctx.fill();

    // Floating bob
    const bob = Math.sin(performance.now() * 0.008 + coin.z * 0.1) * 3 * scale;
    ctx.translate(0, -20 * scale + bob);

    // Glowing Gold Coin Disc
    ctx.fillStyle = '#ffb800';
    ctx.shadowColor = '#ffb800';
    ctx.shadowBlur = 12 * scale;
    ctx.beginPath();
    ctx.ellipse(0, 0, Math.max(1, r * Math.abs(spinWidth)), r, 0, 0, Math.PI * 2);
    ctx.fill();

    // Inner Specular Rim
    if (Math.abs(spinWidth) > 0.35) {
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.ellipse(0, 0, r * 0.65 * Math.abs(spinWidth), r * 0.65, 0, 0, Math.PI * 2);
      ctx.fill();

      // Coin Star Motif
      ctx.fillStyle = '#b45309';
      ctx.beginPath();
      ctx.arc(0, 0, 3 * scale, 0, Math.PI * 2);
      ctx.fill();
    }

    ctx.restore();
  }

  renderPowerup(ctx, pu) {
    const proj = this.project(pu.x, pu.z);
    const scale = proj.scale;
    if (scale <= 0.08) return;

    ctx.save();
    const puY = proj.y - (pu.jumpY || 18) * scale;
    ctx.translate(proj.x, puY);

    const bob = Math.sin(performance.now() * 0.006) * 4 * scale;
    ctx.translate(0, -22 * scale + bob);

    const size = 22 * scale;

    // Luminous Powerup Orb
    let color = '#00f3ff';
    let icon = '🧲';
    if (pu.type === POWERUP_TYPES.SHIELD) {
      color = '#00ff88';
      icon = '🛡️';
    } else if (pu.type === POWERUP_TYPES.BOOST) {
      color = '#ffb800';
      icon = '⚡';
    } else if (pu.type === POWERUP_TYPES.DOUBLE) {
      color = '#ff007f';
      icon = '🪙';
    }

    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 18 * scale;
    ctx.beginPath();
    ctx.arc(0, 0, size, 0, Math.PI * 2);
    ctx.fill();

    // Inner White Core
    ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
    ctx.beginPath();
    ctx.arc(0, 0, size * 0.65, 0, Math.PI * 2);
    ctx.fill();

    // Icon glyph
    ctx.shadowBlur = 0;
    ctx.font = `${Math.round(16 * scale)}px system-ui, sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(icon, 0, 0);

    ctx.restore();
  }

  // ==========================================================================
  // CARTOON 3D RUNNER (Hoodie, Backpack, Trousers, Sneakers)
  // ==========================================================================
  renderPlayer(ctx) {
    const px = this.player.x;
    const py = this.roadBottomY - this.player.jumpY;
    const isSliding = this.player.isSliding;
    const skin = SKINS[this.storage.skin] || SKINS.classic;

    ctx.save();
    ctx.translate(px, py);

    // Lean into turns
    ctx.rotate(this.player.tilt);

    // Landing impact squash & stretch
    if (this.landingSquash > 0.01) {
      const squashFactor = this.landingSquash * 0.14;
      ctx.scale(1.0 + squashFactor, 1.0 - squashFactor);
    }

    // Invulnerability Blink Effect
    if (this.invulnerableTimer > 0 && Math.floor(performance.now() / 80) % 2 === 0) {
      ctx.globalAlpha = 0.45;
    }

    // Dynamic Ground Shadow (projects directly onto railway tracks)
    const shadowScale = Math.max(0.3, 1 - this.player.jumpY / 180);
    ctx.fillStyle = 'rgba(0, 0, 0, 0.65)';
    ctx.beginPath();
    ctx.ellipse(0, 4, 30 * shadowScale, 9 * shadowScale, 0, 0, Math.PI * 2);
    ctx.fill();

    // SHIELD BUBBLE (When Shield Power-Up is Active)
    if (this.activePowerups.shield) {
      ctx.save();
      const shieldPulse = Math.sin(performance.now() * 0.008) * 3;
      ctx.strokeStyle = '#00ff88';
      ctx.shadowColor = '#00ff88';
      ctx.shadowBlur = 20;
      ctx.lineWidth = 3.5;
      ctx.fillStyle = 'rgba(0, 255, 136, 0.15)';
      ctx.beginPath();
      ctx.arc(0, isSliding ? -18 : -50, (isSliding ? 34 : 52) + shieldPulse, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    // BOOST DASH FIRE TRAILS (When Boost is Active)
    if (this.activePowerups.boost > 0) {
      ctx.save();
      ctx.fillStyle = 'rgba(255, 184, 0, 0.35)';
      ctx.beginPath();
      ctx.ellipse(0, -45, 36, 56, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    if (isSliding) {
      // ======================================================================
      // PARKOUR ROLL / SLIDING RUNNER (Low clearance under barriers)
      // ======================================================================
      const slideRoll = (1 - this.player.slideTimer / 0.65) * Math.PI * 2;

      ctx.save();
      ctx.translate(0, -18);
      ctx.rotate(slideRoll * 0.3);

      // Hoodie Body (Tucked into low roll)
      ctx.fillStyle = skin.hoodie;
      ctx.beginPath();
      ctx.roundRect(-24, -14, 48, 26, 12);
      ctx.fill();

      // Streetwear Backpack tucked tight
      ctx.fillStyle = skin.backpack;
      ctx.beginPath();
      ctx.roundRect(-22, -18, 16, 16, 6);
      ctx.fill();

      // Jogger Legs tucked back
      ctx.fillStyle = '#1e293b';
      ctx.beginPath();
      ctx.roundRect(-28, -6, 20, 14, 6);
      ctx.fill();

      // Chunky Sneaker
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(-32, -4, 12, 8);
      ctx.fillStyle = skin.sneakers;
      ctx.fillRect(-32, -1, 12, 3);

      // Head / Hood
      ctx.fillStyle = skin.accent;
      ctx.beginPath();
      ctx.arc(14, -4, 12, 0, Math.PI * 2);
      ctx.fill();

      // Glowing Visor / Goggles
      ctx.fillStyle = skin.visor;
      ctx.shadowColor = skin.visor;
      ctx.shadowBlur = 10;
      ctx.fillRect(16, -6, 8, 5);
      ctx.shadowBlur = 0;

      ctx.restore();
    } else {
      // ======================================================================
      // CARTOON 3D RUNNER (Rear Perspective: Hoodie, Backpack, Joggers, Sneakers)
      // ======================================================================
      const runCycle = this.player.runCycle;
      const bob = Math.sin(runCycle * 2) * 3.5;

      const leftLegAngle = Math.sin(runCycle) * 0.65;
      const rightLegAngle = -Math.sin(runCycle) * 0.65;
      const leftArmAngle = -Math.sin(runCycle) * 0.75;
      const rightArmAngle = Math.sin(runCycle) * 0.75;

      // 1. Jogger Legs & Chunky Sneakers
      if (this.player.isJumping) {
        // Athletic Jump: Knees tucked upward, sneakers pointing downward
        ctx.fillStyle = '#1e293b';
        // Left Leg
        ctx.save();
        ctx.translate(-10, -32);
        ctx.rotate(-0.35);
        ctx.fillRect(-5, 0, 10, 22);
        // Chunky Sneaker with Sole
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(-6, 20, 14, 10, 4);
        ctx.fill();
        ctx.fillStyle = skin.sneakers;
        ctx.fillRect(-6, 26, 14, 4);
        ctx.restore();

        // Right Leg
        ctx.fillStyle = '#1e293b';
        ctx.save();
        ctx.translate(10, -32);
        ctx.rotate(0.35);
        ctx.fillRect(-5, 0, 10, 22);
        // Sneaker
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(-8, 20, 14, 10, 4);
        ctx.fill();
        ctx.fillStyle = skin.sneakers;
        ctx.fillRect(-8, 26, 14, 4);
        ctx.restore();
      } else {
        // Full Running Stride (Alternating legs with articulated knees and sneakers)
        // Left Leg
        ctx.save();
        ctx.translate(-8, -32 + bob);
        ctx.rotate(leftLegAngle);
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-5, 0, 10, 26);
        // Sneaker (sole kicks up on back-stride)
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(-6, 24, 14, 9, 3);
        ctx.fill();
        ctx.fillStyle = skin.sneakers;
        ctx.fillRect(-6, 29, 14, 4);
        ctx.restore();

        // Right Leg
        ctx.save();
        ctx.translate(8, -32 + bob);
        ctx.rotate(rightLegAngle);
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-5, 0, 10, 26);
        // Sneaker
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.roundRect(-8, 24, 14, 9, 3);
        ctx.fill();
        ctx.fillStyle = skin.sneakers;
        ctx.fillRect(-8, 29, 14, 4);
        ctx.restore();
      }

      // 2. Arms (Swing behind/forward at sides)
      if (this.player.isJumping) {
        // Arms spread for aerial balance
        ctx.fillStyle = skin.accent;
        ctx.save();
        ctx.translate(-19, -60 + bob);
        ctx.rotate(-0.85);
        ctx.fillRect(-4, 0, 9, 24);
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(0, 25, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        ctx.fillStyle = skin.accent;
        ctx.save();
        ctx.translate(19, -60 + bob);
        ctx.rotate(0.85);
        ctx.fillRect(-5, 0, 9, 24);
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(0, 25, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      } else {
        // Left Arm swinging naturally
        ctx.save();
        ctx.translate(-19, -60 + bob);
        ctx.rotate(leftArmAngle);
        ctx.fillStyle = skin.accent;
        ctx.fillRect(-4, 0, 8, 22);
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(0, 23, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Right Arm swinging opposite
        ctx.save();
        ctx.translate(19, -60 + bob);
        ctx.rotate(rightArmAngle);
        ctx.fillStyle = skin.accent;
        ctx.fillRect(-4, 0, 8, 22);
        ctx.fillStyle = '#ffedd5';
        ctx.beginPath();
        ctx.arc(0, 23, 4.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // 3. Torso: Styled Cyber Hoodie (Back View)
      ctx.fillStyle = skin.hoodie;
      ctx.beginPath();
      ctx.roundRect(-19, -68 + bob, 38, 38, 9);
      ctx.fill();

      // Hoodie Shoulder Seams
      ctx.strokeStyle = skin.accent;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(-16, -64 + bob);
      ctx.lineTo(-8, -68 + bob);
      ctx.moveTo(16, -64 + bob);
      ctx.lineTo(8, -68 + bob);
      ctx.stroke();

      // 4. Streetwear Cyber Backpack
      ctx.fillStyle = skin.backpack;
      ctx.shadowColor = skin.backpack;
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.roundRect(-14, -65 + bob, 28, 26, 8);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Backpack Zip Pocket & Flap
      ctx.fillStyle = 'rgba(0, 0, 0, 0.4)';
      ctx.beginPath();
      ctx.roundRect(-10, -56 + bob, 20, 14, 5);
      ctx.fill();

      // Glowing Neon Energy Battery Core on Backpack
      ctx.fillStyle = skin.visor;
      ctx.shadowColor = skin.visor;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(0, -49 + bob, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      // Shoulder Straps holding the backpack
      ctx.fillStyle = 'rgba(0, 0, 0, 0.6)';
      ctx.fillRect(-14, -68 + bob, 4, 12);
      ctx.fillRect(10, -68 + bob, 4, 12);

      // 5. Head & Streetwear Hood (Back of head with hood pulled up)
      ctx.fillStyle = skin.accent;
      ctx.beginPath();
      ctx.arc(0, -82 + bob, 15, 0, Math.PI * 2);
      ctx.fill();

      // Center Hood Seam
      ctx.strokeStyle = 'rgba(0, 0, 0, 0.3)';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.moveTo(0, -97 + bob);
      ctx.lineTo(0, -70 + bob);
      ctx.stroke();

      // Neon Collar / Visor Band
      ctx.strokeStyle = skin.backpack;
      ctx.lineWidth = 3.5;
      ctx.shadowColor = skin.backpack;
      ctx.shadowBlur = 8;
      ctx.beginPath();
      ctx.arc(0, -74 + bob, 14, 0.2, Math.PI - 0.2);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    ctx.restore();
  }

  // ==========================================================================
  // MAIN GAME TICK
  // ==========================================================================
  loop(timestamp) {
    if (!this.lastTime) this.lastTime = timestamp;
    const rawDt = (timestamp - this.lastTime) / 1000;
    this.lastTime = timestamp;

    const dt = Math.min(rawDt, 0.05);

    this.update(dt);
    this.render();

    requestAnimationFrame((t) => this.loop(t));
  }
}

// Reliable Bootstrap: checks readyState in case DOMContentLoaded has already fired
function bootstrapGame() {
  if (typeof window !== 'undefined' && !window.__neonDashInstance) {
    window.__neonDashInstance = new NeonDashGame();
  }
}

if (typeof document !== 'undefined') {
  if (document.readyState === 'loading') {
    window.addEventListener('DOMContentLoaded', bootstrapGame);
  } else {
    bootstrapGame();
  }
}
